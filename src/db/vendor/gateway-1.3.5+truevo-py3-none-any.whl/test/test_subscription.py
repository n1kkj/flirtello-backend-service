from gateway import Txn, CreateSubscription, Channel, UpdateSubscription, \
    DeactivateSubscription, Address, NotificationSettings, Customer, \
    ScheduleUpdateSubscription, GetSubscriptionDetails
from gateway.common import ApiType, Fields
from gateway.request import HttpMethod
from test.test_common import GatewaySetup
import json

APPLY_DATE = '2022-10-20 20:50'
CUSTOMER = 'CUS123'
PLAN_ID = 'PLN123'
START_DATE = '2022-10-20 11:49'
SUBSCRIPTION_ID = 'SUB123'


class TestSubscription(GatewaySetup):

    def setUp(self):
        super().setUp()
        self.txn = Txn()


class TestCreateSubscription(TestSubscription):

    def test_encode_customer_id(self):
        # given
        customer_id = "foo"
        txn = Txn("foo")
        subscription = CreateSubscription(customer_id=customer_id,
                                          txn=txn,
                                          plan_id=PLAN_ID,
                                          start_date=START_DATE,
                                          quantity=2)

        # when
        data = subscription.encode().decode()
        actual = json.loads(data)

        # then
        expected = {
            "external": False,
            "lang": "en",
            "merchant": {
                "customerID": "foo",
                "merchantID": "GIT210317001"
            },
            "planId": "PLN123",
            "quantity": 2,
            "startDate": "2022-10-20 11:49",
            "transaction": {
                "txnReference": "foo",
            },
        }
        self.assertDictEqual(expected, actual)

    def test_encode_customer(self):
        # given
        dob = "1111-22-33"
        ip_address = "123.123.123.123"
        billing_firstname = "foo"
        billing = Address(firstname=billing_firstname)
        shipping_firstname = "bar"
        shipping = Address(firstname=shipping_firstname)
        channel_name = "sms"
        channel_value = "qux"
        channel = NotificationSettings(channel_name, channel_value)
        customer = Customer(dob=dob,
                            ip_address=ip_address,
                            billing=billing,
                            shipping=shipping,
                            channel=channel)
        customer_id = "foo"
        txn = Txn("foo")
        subscription = CreateSubscription(customer_id=customer_id,
                                          txn=txn,
                                          plan_id=PLAN_ID,
                                          start_date=START_DATE,
                                          quantity=2,
                                          customer=customer)
        # when
        data = subscription.encode().decode()
        actual = json.loads(data)

        # then
        expected = {
            "external": False,
            "lang": "en",
            "merchant": {
                "customerID": "foo",
                "merchantID": "GIT210317001"
            },
            "planId": "PLN123",
            "quantity": 2,
            "startDate": "2022-10-20 11:49",
            "transaction": {
                "txnReference": "foo",
            },
            "customer": {
                "dob": dob,
                "ipAddress": ip_address,
                "billingAddress": {
                    "firstName": "foo",
                    "lastName": None,
                    "mobileNo": None,
                    "emailId": None
                },
                "shippingAddress": {
                    "sFirstName": "bar",
                    "sLastName": None,
                    "sMobileNo": None,
                    "sEmailId": None
                },
                "notificationChannels": [
                    {
                        "name": channel_name,
                        "value": channel_value,
                    },
                ]
            },
        }
        self.assertDictEqual(expected, actual)

    def test_to_dict(self):
        req = CreateSubscription(customer_id=CUSTOMER, plan_id=PLAN_ID,
                                 txn=self.txn,
                                 start_date=START_DATE,
                                 quantity=2)
        self.assertIsNotNone(req)
        self.assertEqual(req.signature, ApiType.CREATE_SUBSCRIPTION)
        self.assertEqual(req.method, HttpMethod.post.value)
        json = req.to_dict()
        self.assertIsNotNone(json)
        self.assertIsNotNone(json.get(Fields.merchant.value))
        self.assertIsNone(json.get(Fields.customer.value))
        self.assertIsNotNone(json.get(Fields.transaction.value))
        self.assertIsNotNone(json.get(Fields.merchant.value))
        self.assertIsNotNone(
            json.get(Fields.transaction.value).get(Fields.txn_ref.value))
        self.assertEqual(json.get(Fields.plan_id.value), PLAN_ID)


class TestUpdateSubscription(TestSubscription):

    def test_details(self):
        req = UpdateSubscription(customer_id=CUSTOMER,
                                 subscription_id=SUBSCRIPTION_ID,
                                 txn=self.txn,
                                 start_date=START_DATE,
                                 channel=Channel.email, quantity=2)
        test_api_details(self, req, ApiType.UPDATE_SUBSCRIPTION,
                         HttpMethod.put.value)


class TestDeactivateSubscription(TestSubscription):

    def test_details(self):
        req = DeactivateSubscription(subscription_id=SUBSCRIPTION_ID)
        test_api_details(self, req, ApiType.DEACTIVATE_SUBSCRIPTION,
                         HttpMethod.delete.value)


class TestGetSubscriptionDetails(TestSubscription):

    def test_details(self):
        req = GetSubscriptionDetails(subscription_id=SUBSCRIPTION_ID)
        test_api_details(self, req, ApiType.GET_SUBSCRIPTION_DETAILS,
                         HttpMethod.get.value)


class TestScheduleUpdateSubscription(TestSubscription):

    def test_to_dict(self):
        req = ScheduleUpdateSubscription(subscription_id=SUBSCRIPTION_ID,
                                         plan_id=PLAN_ID,
                                         start_date=START_DATE,
                                         apply_date=APPLY_DATE,
                                         quantity=2)
        test_api_details(self, req, ApiType.SCHEDULE_UPDATE_SUBSCRIPTION,
                         HttpMethod.put.value)
        self.assertEqual(req.plan_id, PLAN_ID)
        self.assertEqual(req.apply_date, APPLY_DATE)


def test_api_details(self, req, signature, method_name):
    self.assertIsNotNone(req)
    self.assertEqual(req.signature, signature)
    self.assertEqual(req.method, method_name)
    self.assertEqual(req.txn_id, SUBSCRIPTION_ID)
