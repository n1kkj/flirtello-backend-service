from gateway.api_resources import BankDetails
from gateway.common import Fields
from unittest import TestCase


class TestBankDetails(TestCase):

    def test_to_dict(self):
        json = BankDetails(iban="26105906", bic="01022", holder="test") \
                .to_dict()
        self.assertTrue(json.get(Fields.iban.value))
        self.assertTrue(json.get(Fields.bic.value))
        self.assertTrue(json.get(Fields.holder.value))
