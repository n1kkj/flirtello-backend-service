from gateway import Payout, ApprovePayout, DeclinePayout, \
    PaymentMethod, CustomerID, Txn, Currency, Url
from test.test_common import GatewaySetup


class TestPayout(GatewaySetup):

    def test_to_dict(self):
        payment = PaymentMethod()
        txn = Txn("TXN123", "12.99", Currency.EUR)
        customer_id = CustomerID("bar"),
        url = Url(
            "https://www.foo.com",
            "https://www.bar.com",
            "https://www.baz.com",
        )
        payout = Payout(
            txn,
            customer_id,
            payment,
            url,
            "bar@baz.com",
        )
        actual = payout.to_dict()
        expected = {
           "lang": "en",
           "merchant": {
              "customerID": customer_id,
              "merchantID": "GIT210317001",
           },
           "transaction": {
                "async": True,
                "currencyCode": Currency.EUR,
                "customerEmail": "bar@baz.com",
                "hostedPage": True,
                "isApp": False,
                "payout": 'true',
                "txnAmount": "12.99",
                "txnReference": "TXN123"
           },
           "url": url
        }
        self.assertDictEqual(actual, expected)


class TestApprovePayout(GatewaySetup):

    def test_approve_payout(self):
        approve_payout = ApprovePayout("TXN123")
        self.assertEqual(approve_payout._txn_id, "TXN123")
        self.assertEqual(approve_payout._signature, "processPayout")
        self.assertEqual(approve_payout._method, "put")
        self.assertEqual(approve_payout._route, "/GIT210317001/payout/TXN123")


class TestDeclinePayout(GatewaySetup):

    def test_decline_payout(self):
        approve_payout = DeclinePayout("TXN123")
        self.assertEqual(approve_payout._txn_id, "TXN123")
        self.assertEqual(approve_payout._signature, "processPayout")
        self.assertEqual(approve_payout._method, "delete")
        self.assertEqual(approve_payout._route, "/GIT210317001/payout/TXN123")
