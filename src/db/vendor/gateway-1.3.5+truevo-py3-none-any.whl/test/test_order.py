from gateway.api_resources.order import CustomData, \
    Order, Url

from test.test_common import GatewaySetup


class TestCustomData(GatewaySetup):

    def test_all_fields(self):
        # given
        custom_data1 = "foo"
        custom_data2 = "bar"
        custom_data3 = "baz"
        custom_data4 = "qux"
        custom_data5 = "quux"
        site = "corge"
        custom_data = CustomData(custom_data1=custom_data1,
                                 custom_data2=custom_data2,
                                 custom_data3=custom_data3,
                                 custom_data4=custom_data4,
                                 custom_data5=custom_data5,
                                 site=site)

        # when
        actual = custom_data.to_dict()

        # then
        expected = {
            "customData1": custom_data1,
            "customData2": custom_data2,
            "customData3": custom_data3,
            "customData4": custom_data4,
            "customData5": custom_data5,
            "site": site,
        }
        self.assertDictEqual(expected, actual)

    def test_one_field(self):
        # given
        custom_data1 = "foo"
        custom_data = CustomData(custom_data1=custom_data1)

        # when
        actual = custom_data.to_dict()

        # then
        expected = {
            "customData1": custom_data1,
        }
        self.assertDictEqual(expected, actual)

    def test_all_none(self):
        # given
        custom_data = CustomData()

        # when
        actual = custom_data.to_dict()

        # then
        expected = {}
        self.assertDictEqual(expected, actual)


class TestSummaryAndItems(GatewaySetup):

    def test_to_dict_total_value(self):
        order = Order(
            total_value="19.07",
        )
        actual = order.to_dict()
        expected = "19.07"
        self.assertEqual(actual["summary"]["totalValue"], expected)

    def test_to_dict_discount(self):
        discount = {
            "total": "0.40",
            "coupon_detail": "foo",
            "coupon_code": "FIRST40",
        }
        order = Order(
            discount=discount,
        )
        actual = order.to_dict()
        expected = {
            "discountValue": "0.40",
            "couponCode": "FIRST40",
            "couponCodeDetails": "foo"
        }
        self.assertEqual(actual["summary"]["discount"].to_dict(), expected)

    def test_to_dict_details(self):
        details = {
            "shipping": "0.55",
            "tax": "0.03",
            "subtotal": "19.41",
        }
        order = Order(
            total_value="19.07",
            details=details,
        )
        actual = order.to_dict()
        expected = {
            "subtotal": "19.41",
            "tax": "0.03",
            "shippingCharges": "0.55"
        }
        self.assertEqual(actual["summary"]["details"].to_dict(), expected)

    def test_to_dict_items(self):
        item = {
            "name": "RBK fitness shoes",
            "qty": "2",
            "price": "2.49",
            "sku": "ITM001",
        }
        order = Order()
        order.add_item(item)
        actual = order.to_dict()
        expected = {
            "itemName": "RBK fitness shoes",
            "itemId": "ITM001",
            "itemPricePerUnit": "2.49",
            "itemQuantity": "2"
        }
        self.assertDictEqual(actual["items"][0].to_dict(), expected)


class TestUrl(GatewaySetup):

    def test_to_dict(self):
        url = Url(
            success="https://www.foo.com",
            fail="https://www.bar.com",
            cancel="https://www.baz.com",
            cart="https://www.qux.com",
            product="https://www.quux.com",
            confirmation_page=True,
            iframe=True,
        )
        actual = url.to_dict()
        expected = {
            "successURL": "https://www.foo.com",
            "failURL": "https://www.bar.com",
            "cancelURL": "https://www.baz.com",
            "cartURL": "https://www.qux.com",
            "productURL": "https://www.quux.com",
            "showConfirmationPage": True,
            "iFrame": True,
        }
        self.assertDictEqual(actual, expected)
