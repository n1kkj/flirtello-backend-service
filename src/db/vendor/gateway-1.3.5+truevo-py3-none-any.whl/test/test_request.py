from os.path import dirname
from unittest import TestCase

import gateway.api as _api
from gateway.exceptions import GatewayError
from gateway.request import AuthTokenRequest


class TestAuthTokenRequest(TestCase):
    X_SDK_VERSION = 'X-SDK-Version'
    AUTHORIZATION = 'Authorization'
    DATE_HEADER = 'dateHeader'

    def setUp(self):
        self.key = 'GIT210317001'
        self.token = '3Qtpz6S04ou/8lfpt/dd7Fjlr8gnmb/8'
        self.cert = dirname(__file__) + '/files/certificate.pem'
        self.api = _api.Api(self.key, self.token, self.cert)

    def test_get_headers_dict(self):
        auth_req = AuthTokenRequest(self.api)
        auth_req._name = "auth_token_test"
        self.assertIsNotNone(auth_req)
        self.attribute_error_check(auth_req)
        auth_req._signature = "test_signature"
        self.attribute_error_check(auth_req)
        auth_req._txn_id = "REF123"
        header = auth_req.get_headers_dict()
        self.assertIsNotNone(header)
        self.assertIsNotNone(header.get(self.AUTHORIZATION))
        self.assertIsNotNone(header.get(self.DATE_HEADER))
        self.assertIsNotNone(header.get(self.X_SDK_VERSION))

    def attribute_error_check(self, auth_req):
        try:
            auth_req.get_headers_dict()
        except AttributeError:
            pass
        except GatewayError:
            self.fail('unexpected exception raised')
