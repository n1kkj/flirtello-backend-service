from os.path import dirname
from unittest import TestCase

import gateway
from gateway.common import UIDType, Fields, Varien


class GatewaySetup(TestCase):

    def setUp(self):
        self.key = 'GIT210317001'
        self.token = '3Qtpz6S04ou/8lfpt/dd7Fjlr8gnmb/8'
        self.cert = dirname(__file__) + '/files/certificate.pem'
        self.api = gateway.configure(key=self.key, token=self.token,
                                     cert=self.cert)


class TestCommon(TestCase):

    def test_uid_type(self):
        with self.assertRaises(TypeError):
            UIDType()
        test_value = 100
        obj = UIDType(test_value)
        self.assertEqual(obj, test_value)
        self.assertNotEqual(obj, test_value + 1)
        self.assertEqual(str(UIDType(None)), "")

    def test_field_value(self):
        for _, value in Fields.__dict__.items():
            if isinstance(value, Fields):
                self.assertIsNotNone(value.value)


class TestVarien(TestCase):

    def test_to_dict(self):
        actual = {}
        expected = Varien().to_dict()
        self.assertIsNotNone(expected)
        self.assertEqual(expected, actual)
