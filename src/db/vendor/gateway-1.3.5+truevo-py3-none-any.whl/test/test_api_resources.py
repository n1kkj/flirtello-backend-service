from unittest import TestCase
from gateway.api_resources.timezone import get_timezone_dict, TimeZone
from gateway.api_resources import (
    Currency,
    Language,
    Txn,
    Token,
    Events,
)


class test_timezone(TestCase):

    def test_timezone_collection(self):
        tz = get_timezone_dict()
        self.assertTrue(isinstance(tz, dict), msg="Type is not dict")
        for test_value in ("UTC", "IST", "GMT"):
            self.assertEqual(tz[test_value], test_value)
        for test_value in ("Asia/Kolkata", "Europe/Amsterdam", None):
            with self.assertRaises(KeyError):
                tz[test_value]

    def test_timezone(self):
        for test_value in ("UTC", "IST", "GMT"):
            self.assertEqual(TimeZone(test_value).value, test_value)
        for test_value in ("Asia/Kolkata", "Europe/Amsterdam", None):
            with self.assertRaises(ValueError):
                TimeZone(test_value)


class test_common_type(TestCase):

    def test_currency(self):
        for test_value in ("CAD", "INR", "EUR"):
            self.assertEqual(Currency(test_value).value, test_value)
        for test_value in ("Dollars", "Euro", None):
            with self.assertRaises(ValueError):
                Currency(test_value)

    def test_locale(self):
        for test_value in ("en", "de", "ar"):
            self.assertEqual(Language(test_value).value, test_value)
        for test_value in ("English", "EN", "Dutch", None):
            with self.assertRaises(ValueError):
                Language(test_value)

    def test_events(self):
        for test_value in ("*", "chargeback", "cancel"):
            self.assertEqual(Events(test_value).value, test_value)
        for test_value in ("all", "Chargeback", None):
            with self.assertRaises(ValueError):
                Events(test_value)


class test_uid_subtype(TestCase):

    def test_txn(self):
        tobj = Txn()
        self.assertLessEqual(len(str(tobj)), 36)
        self.assertRegex(str(tobj), r"^([a-zA-Z0-9]{4}-?)+$")
        self.assertEqual(tobj, tobj.uid)
        self.assertEqual(Txn(10), 10)
        self.assertNotEqual(Txn(), None)

    def test_token(self):
        self.assertEqual(Token("100"), 100)
        with self.assertRaises(TypeError):
            Token()
