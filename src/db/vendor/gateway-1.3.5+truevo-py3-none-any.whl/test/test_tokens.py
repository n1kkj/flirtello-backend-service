from gateway import GetAcquirerTokens, GetSavedCards, DeleteToken, \
    CardDetails, SaveCard, SaveAcquirerTokens
from gateway.common import Fields, Route
from test.test_common import GatewaySetup

CUSTOMER_ID = 'CUST123'
TOKEN_ID = 'TOK123456'


class TestTokenRequest(GatewaySetup):
    pass


class TestGetAcquirerTokens(TestTokenRequest):

    def test_to_dict(self):
        req = GetAcquirerTokens(customer_id=CUSTOMER_ID)
        test_common_details(self, req)


class TestGetSavedCards(TestTokenRequest):

    def test_to_dict(self):
        req = GetSavedCards(customer_id=CUSTOMER_ID)
        json = test_common_details(self, req)
        self.assertTrue(json.get(Fields.all_cards.value))


class TestDeleteToken(TestTokenRequest):

    def test_to_dict(self):
        req = DeleteToken(customer_id=CUSTOMER_ID, token=TOKEN_ID)
        test_common_details(self, req)


class TestSaveCard(TestTokenRequest):

    def test_to_dict(self):
        card_info = CardDetails(number="4200000000000000", name="John Doe",
                                cvv="578", expiry_year=2029,
                                expiry_month='05')
        req = SaveCard(customer_id=CUSTOMER_ID, card_detail=card_info)
        json = test_common_details(self, req)
        self.assertIsNotNone(json.get(Fields.card.value))


class TestSaveAcquirerTokens(TestTokenRequest):

    def test_to_dict(self):
        req = SaveAcquirerTokens(customer_id=CUSTOMER_ID, token=TOKEN_ID,
                                 acquirer='test', expiry_month='12',
                                 expiry_year='2026', name='test',
                                 bank_info_number='123', last4='4556')
        json = test_common_details(self, req)
        self.assertIsNotNone(json.get(Fields.token.value))
        self.assertIsNotNone(
            json.get(Fields.token.value).get(Fields.card_year.value))
        self.assertIsNotNone(
            json.get(Fields.token.value).get(Fields.card_last4.value))


def test_common_details(self, req):
    self.assertIsNotNone(req)
    json = req.to_dict()
    self.assertEqual(json.get(Fields.merchant_id.value), self.api.key)
    self.assertEqual(json.get(Fields.customer_id.value), CUSTOMER_ID)
    self.assertEqual(req.route, Route.PARTNER_API)
    return json
