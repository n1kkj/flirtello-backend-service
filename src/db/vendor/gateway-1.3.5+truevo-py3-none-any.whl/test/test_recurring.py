from gateway.api_resources.recurring import Recurring, Source, \
    Reason, RecurringType

from test.test_common import GatewaySetup


class TestRecurring(GatewaySetup):

    def test_all_fields(self):
        # given
        source = Source.CIT
        recurring_type = RecurringType.RECURRING
        reason = Reason.DELAYED_CHARGES
        recurring = Recurring(source=source,
                              recurring_type=recurring_type,
                              reason=reason)

        # when
        actual = recurring.to_dict()

        # then
        expected = {
            "source": source,
            "recurringType": recurring_type,
            "reason": reason,
        }
        self.assertDictEqual(expected, actual)

    def test_one_field(self):
        # given
        source = Source.CIT
        recurring = Recurring(source=source)

        # when
        actual = recurring.to_dict()

        # then
        expected = {
            "source": source,
        }
        self.assertDictEqual(expected, actual)

    def test_none_field(self):
        # given
        recurring = Recurring()

        # when
        actual = recurring.to_dict()

        # then
        expected = {}
        self.assertDictEqual(expected, actual)
