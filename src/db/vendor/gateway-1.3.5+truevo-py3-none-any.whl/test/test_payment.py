from gateway import Txn, Currency, \
    Url, Payment, PaymentMethod, Address, \
    CustomData, Recurring, Source, Customer, \
    NotificationSettings, Order, DynamicDescriptor
from gateway.request import HttpMethod
from gateway.common import Fields, Route
from test.test_common import GatewaySetup

import json


class TestPayment(GatewaySetup):

    maxDiff = None

    def test_details(self):
        txn = Txn(None, 10, Currency.EUR)
        customer_id = 'CUST123'
        url = Url("https://success.html",
                  "https://fail.html",
                  "https://cancel.html")
        billing = Address(firstname='John',
                          lastname='Doe',
                          email='john@doe.com',
                          phone_no='123123123')
        shipping = Address(firstname='Alice',
                           lastname='Targ',
                           email='alice@targ.com',
                           phone_no='321321321')
        customer = Customer(billing=billing,
                            shipping=shipping)

        req = Payment(
                txn,
                customer_id,
                PaymentMethod(),
                url,
                customer=customer
        )
        self.assertIsNotNone(req)
        self.assertIsNotNone(req._txn_id)
        self.assertEqual(req.method, HttpMethod.post.value)
        self.assertEqual(req.route, Route.PARTNER_API)
        json = req.to_dict()
        self.assertIsNotNone(json.get(Fields.customer.value))
        self.assertIsNotNone(json.get(Fields.transaction.value))

    def test_gen_payment_link(self):
        # given
        txn = Txn("foo")
        payment = Payment(txn, None, None, None).generate_payment_link()

        # when
        data = payment.encode().decode()
        actual = json.loads(data)

        # then
        expected = {
            "lang": "en",
            "merchant": {
                "merchantID": self.key,
                "customerID": "",
            },
            "transaction": {
                "txnAmount": 0,
                "currencyCode": None,
                "txnReference": "foo",
                "async": True,
                "isApp": False,
                "payout": False,
                "paymentLink": True,
                "allowBillShip": True
            },
            "url": None,
        }
        self.assertDictEqual(expected, actual)

    def test_encode_custom_data(self):
        # given
        custom_data1 = "foo"
        custom_data = CustomData(custom_data1=custom_data1)
        txn = Txn("foo")
        payment = Payment(txn, None, None, None, custom_data=custom_data)

        # when
        data = payment.encode().decode()
        actual = json.loads(data)

        # then
        expected = {
            "lang": "en",
            "merchant": {
                "merchantID": self.key,
                "customerID": "",
            },
            "transaction": {
                "txnAmount": 0,
                "currencyCode": None,
                "txnReference": "foo",
                "async": True,
                "isApp": False,
                "payout": False,
            },
            "url": None,
            "customData": {
                "customData1": custom_data1,
            },
        }
        self.assertDictEqual(expected, actual)

    def test_encode_customer_id(self):
        # given
        customer_id = "foo"
        txn = Txn("foo")
        payment = Payment(txn, customer_id, None, None)

        # when
        data = payment.encode().decode()
        actual = json.loads(data)

        # then
        expected = {
            "lang": "en",
            "merchant": {
                "merchantID": self.key,
                "customerID": customer_id,
            },
            "transaction": {
                "txnAmount": 0,
                "currencyCode": None,
                "txnReference": "foo",
                "async": True,
                "isApp": False,
                "payout": False,
            },
            "url": None,
        }
        self.assertDictEqual(expected, actual)

    def test_encode_recurring(self):
        # given
        txn = Txn("foo")
        source = Source.CIT
        recurring = Recurring(source=source)
        payment = Payment(txn, None, None, None, recurring=recurring)

        # when
        data = payment.encode().decode()
        actual = json.loads(data)

        # then
        expected = {
            "lang": "en",
            "merchant": {
                "merchantID": self.key,
                "customerID": "",
            },
            "transaction": {
                "txnAmount": 0,
                "currencyCode": None,
                "txnReference": "foo",
                "async": True,
                "isApp": False,
                "payout": False,
            },
            "url": None,
            "recurring": {
                "source": "CIT",
            }
        }
        self.assertDictEqual(expected, actual)

    def test_encode_customer(self):
        # given
        dob = "1111-22-33"
        ip_address = "123.123.123.123"
        billing_firstname = "foo"
        billing = Address(firstname=billing_firstname)
        shipping_firstname = "bar"
        shipping = Address(firstname=shipping_firstname)
        channel_name = "sms"
        channel_value = "qux"
        channel = NotificationSettings(channel_name, channel_value)
        txn = Txn("foo")
        customer = Customer(dob=dob,
                            ip_address=ip_address,
                            billing=billing,
                            shipping=shipping,
                            channel=channel)
        payment = Payment(txn, None, None, None, customer=customer)

        # when
        data = payment.encode().decode()
        actual = json.loads(data)

        # then
        expected = {
            "lang": "en",
            "merchant": {
                "merchantID": self.key,
                "customerID": "",
            },
            "transaction": {
                "txnAmount": 0,
                "currencyCode": None,
                "txnReference": "foo",
                "async": True,
                "isApp": False,
                "payout": False,
            },
            "url": None,
            "customer": {
                "dob": dob,
                "ipAddress": ip_address,
                "billingAddress": {
                    "firstName": "foo",
                    "lastName": None,
                    "mobileNo": None,
                    "emailId": None
                },
                "shippingAddress": {
                    "sFirstName": "bar",
                    "sLastName": None,
                    "sMobileNo": None,
                    "sEmailId": None
                },
                "notificationChannels": [
                    {
                        "name": channel_name,
                        "value": channel_value,
                    },
                ]
            },
        }
        self.assertDictEqual(expected, actual)

    def test_encode_summary(self):
        txn = Txn("foo")
        order = Order(
            total_value="19.07",
        )
        payment = Payment(txn, None, None, None, order=order)

        data = payment.encode().decode()
        actual = json.loads(data)

        expected = {
            "lang": "en",
            "merchant": {
                "merchantID": self.key,
                "customerID": "",
            },
            "transaction": {
                "txnAmount": 0,
                "currencyCode": None,
                "txnReference": "foo",
                "async": True,
                "isApp": False,
                "payout": False,
            },
            "url": None,
            "summary": {
                "totalValue": "19.07",
            }
        }
        self.assertDictEqual(expected, actual)

    def test_encode_dynamic_descriptor(self):
        txn = Txn("foo")
        descriptor = DynamicDescriptor(
            name="foo"
        )
        payment = Payment(
            txn,
            None,
            None,
            None,
            dynamic_descriptor=descriptor
        )

        data = payment.encode().decode()
        actual = json.loads(data)

        expected = {
            "lang": "en",
            "merchant": {
                "merchantID": self.key,
                "customerID": "",
            },
            "transaction": {
                "txnAmount": 0,
                "currencyCode": None,
                "txnReference": "foo",
                "async": True,
                "isApp": False,
                "payout": False,
            },
            "url": None,
            "dynamicDescriptor": {
                "name": "foo",
            }
        }
        self.assertDictEqual(expected, actual)
