from gateway import Capture, Txn, Currency, Void
from gateway.common import Fields, ApiType
from test.test_common import GatewaySetup


class TestBackoffice(GatewaySetup):

    def setUp(self):
        super().setUp()
        self.txn = Txn()


class TestCapture(TestBackoffice):

    def test_to_dict(self):
        req = Capture(txn=self.txn, currency=Currency.EUR)
        test_backoffice_details(self, req, ApiType.CAPTURE_PAYMENT,
                                Fields.capture_txn.value)


class TestVoid(TestBackoffice):

    def test_to_dict(self):
        req = Void(txn=self.txn)
        test_backoffice_details(self, req, ApiType.VOID_PAYMENT,
                                Fields.void_txn.value)


def test_backoffice_details(self, req, signature, field_name):
    self.assertIsNotNone(req)
    self.assertEqual(req._signature, signature)
    self.assertIsNotNone(req.to_dict().get(field_name))
