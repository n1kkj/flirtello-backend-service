from gateway.api_resources.customer import Customer, Address

from gateway.api_resources.channel import Channel, NotificationSettings

from test.test_common import GatewaySetup


class TestCustomer(GatewaySetup):

    def test_all_fields(self):
        # given
        dob = "1111-22-33"
        ip_address = "123.123.123.123"
        billing = Address(first_name="foo")
        shipping = Address(first_name="bar")
        channel = NotificationSettings(Channel.email, "baz@quin.com")

        # when
        customer = Customer(dob=dob,
                            ip_address=ip_address,
                            billing=billing,
                            shipping=shipping,
                            channel=channel)
        actual = customer.to_dict()

        # then
        expected = {
            "dob": dob,
            "ipAddress": ip_address,
            "billingAddress": billing,
            "shippingAddress": shipping,
            "notificationChannels": channel,
        }
        self.assertDictEqual(expected, actual)

    def test_allow_bill_ship_false(self):
        # given
        address = Address(firstname="foo")

        # when
        customer = Customer(billing=address)

        # then
        self.assertFalse(customer.allow_billship())

    def test_allow_bill_ship_true(self):
        # when
        customer = Customer()

        # then
        self.assertTrue(customer.allow_billship())

    def test_asShipping(self):
        # given
        firstname = "foo"
        address = Address(firstname=firstname)

        # when
        customer = Customer(shipping=address)
        customer_dict = customer.to_dict()
        actual = customer_dict["shippingAddress"].to_dict()

        # then
        expected = {
            "sFirstName": firstname,
            "sLastName": None,
            "sMobileNo": None,
            "sEmailId": None,
        }
        self.assertDictEqual(expected, actual)
