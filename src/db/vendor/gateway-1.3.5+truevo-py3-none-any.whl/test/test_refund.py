from gateway import Refund, Txn, RefundStatus
from gateway.common import Fields, ApiType, Route
from test.test_common import GatewaySetup


class TestRefundApi(GatewaySetup):

    def setUp(self):
        super().setUp()
        self.txn = Txn()


class TestRefund(TestRefundApi):

    def test_to_dict(self):
        req = Refund(self.txn, amount=10)
        test_details(self, req, ApiType.REFUND, Fields.refund.value)
        self.assertIsNotNone(req.to_dict().get(Fields.refund.value).get(
            Fields.refund_amount.value))


class TestRefundStatus(TestRefundApi):

    def test_to_dict(self):
        req = RefundStatus(self.txn)
        test_details(self, req, ApiType.REFUND_DETAILS,
                     Fields.refund_status.value)


def test_details(self, req, signature, field_name):
    self.assertIsNotNone(req)
    self.assertEqual(req.signature, signature)
    self.assertEqual(req.route, Route.PARTNER_API)
    json = req.to_dict()
    self.assertEqual(json.get(Fields.merchant_id.value), self.api.key)
    self.assertIsNotNone(json.get(field_name))
    self.assertIsNotNone(json.get(field_name).get(Fields.txn_ref.value))
