from gateway import GetPaymentLinkDetails, DeactivatePaymentLink, \
    UpdatePaymentLink, Customer, Address, NotificationSettings, \
    DynamicDescriptor
from gateway.common import ApiType, Fields, Route
from gateway.request import HttpMethod
from test.test_common import GatewaySetup
import json


class TestPaymentLink(GatewaySetup):
    pass


class TestGetPaymentLinkDetails(TestPaymentLink):

    def test_details(self):
        req = GetPaymentLinkDetails(link_id='LNK12345')
        test_payment_link_details(self, req, ApiType.GET_LINK_DETAILS,
                                  HttpMethod.get.value)


class TestDeactivatePaymentLink(TestPaymentLink):

    def test_details(self):
        req = DeactivatePaymentLink(link_id='LNK12345')
        test_payment_link_details(self, req, ApiType.DEACTIVATE_LINK,
                                  HttpMethod.delete.value)


class TestUpdatePaymentLink(TestPaymentLink):

    def test_encode_customer(self):
        # given
        dob = "1111-22-33"
        ip_address = "123.123.123.123"
        billing_firstname = "foo"
        billing = Address(firstname=billing_firstname)
        shipping_firstname = "bar"
        shipping = Address(firstname=shipping_firstname)
        channel_name = "sms"
        channel_value = "qux"
        channel = NotificationSettings(channel_name, channel_value)
        customer = Customer(dob=dob,
                            ip_address=ip_address,
                            billing=billing,
                            shipping=shipping,
                            channel=channel)
        link_id = "quux"
        payment_link = UpdatePaymentLink(link_id, customer=customer)

        # when
        data = payment_link.encode().decode()
        actual = json.loads(data)

        # then
        expected = {
            "merchantID": self.key,
            "customer": {
                "dob": dob,
                "ipAddress": ip_address,
                "billingAddress": {
                    "firstName": "foo",
                    "lastName": None,
                    "mobileNo": None,
                    "emailId": None
                },
                "shippingAddress": {
                    "sFirstName": "bar",
                    "sLastName": None,
                    "sMobileNo": None,
                    "sEmailId": None
                },
                "notificationChannels": [
                    {
                        "name": channel_name,
                        "value": channel_value,
                    },
                ]
            },
        }
        self.assertDictEqual(expected, actual)

    def test_encode_dynamic_descriptor(self):
        # given
        name = "foo"
        email = "bar@baz.com"
        mobile = "123"
        dynamic_descriptor = DynamicDescriptor(name=name,
                                               email=email,
                                               mobile=mobile)

        link_id = "quux"
        payment_link = UpdatePaymentLink(link_id,
                                         dynamic_descriptor=dynamic_descriptor)

        # when
        data = payment_link.encode().decode()
        actual = json.loads(data)

        # then
        expected = {
            "merchantID": self.key,
            "dynamicDescriptor": {
                "name": name,
                "email": email,
                "mobile": mobile,
            }
        }
        self.assertDictEqual(expected, actual)

    def test_to_dict(self):
        channel = NotificationSettings("sms", "foo")

        customer = Customer(channel=channel)
        req = UpdatePaymentLink(link_id='LNK12345', customer=customer)
        test_payment_link_details(self, req, ApiType.UPDATE_LINK,
                                  HttpMethod.put.value)

        json = req.to_dict()
        self.assertIsNotNone(json)
        self.assertIsNotNone(json.get(Fields.merchant_id.value))
        self.assertIsNotNone(json.get('customer'))


def test_payment_link_details(self, req, signature, method_name):
    self.assertIsNotNone(req)
    self.assertIsNotNone(req.method)
    self.assertIsNotNone(req.link_id)
    self.assertIsNotNone(req._txn_id)
    self.assertIsNotNone(req.route)
    self.assertEqual(req.method, method_name)
    self.assertEqual(req.signature, signature)
    self.assertEqual(req.route,
                     Route.PAYMENT_LINK + '/' + self.api.key +
                     '/' + req.link_id)
