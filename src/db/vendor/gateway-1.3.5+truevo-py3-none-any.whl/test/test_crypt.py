from base64 import b16encode
from os.path import dirname
from unittest import TestCase

from gateway.crypt import Crypt


class test_crypt(TestCase):

    def setUp(self):
        self.crypt = Crypt(
            '3Qtpz6S04ou/8lfpt/dd7Fjlr8gnmb/8',
            dirname(__file__) + '/files/certificate.pem')

    def test_encryptor(self):
        CASES = (
            (
                b'hello world12346',
                b'326C514F1E608B8FAD7105F907E86FE5'
                b'8032764700859F41F0CEE99F71EADAD9'
            ),
            (
                b'test case test c',
                b'326C514F1E608B8FAD7105F907E86FE5'
                b'80FA3448F66B5ABF88B2A9FB28FAC790'
            )
        )
        iv = b'0' * self.crypt.IV_LENGTH
        for test_value, expected in CASES:
            with self.subTest(msg='case=%s' % test_value):
                encryptor = self.crypt.encryptor(iv)
                actual = b16encode((encryptor.update(
                    iv + test_value) + encryptor.finalize()))
                self.assertEqual(expected, actual)

    def test_encrypt(self):
        cases = [b'hello world12346', b'test case test c']
        for x in cases:
            expected = self.crypt.encrypt(x)
            self.assertIsNotNone(expected)

    def test_decrypt(self):
        cases = [
            b'244E903E89EFA81FA0C1BE916A2F2A95593978E879C9A6FFF4985AB5C5'
            b'CCE75B653FFBE1EC9629BB0DC040DF4FA4566B',
            b'320EA2389899BD92B25677382934CDA3A006FD9E9BB3706B894FCACFDB'
            b'0C921E77857A4B521BD192487624ADB5EE9D24'
        ]
        for x in cases:
            expected = self.crypt.decrypt(x)
            self.assertIsNotNone(expected)
