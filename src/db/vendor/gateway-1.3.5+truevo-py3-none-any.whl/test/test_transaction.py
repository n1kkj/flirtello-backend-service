from gateway import TransactionStatus, Txn, Report
from gateway.common import Fields, Route
from test.test_common import GatewaySetup


class TestTransactionStatus(GatewaySetup):

    def test_to_dict(self):
        req = TransactionStatus(txn=Txn())
        self.assertIsNotNone(req)
        json = req.to_dict()
        self.assertIsNotNone(json.get(Fields.txn_ref.value))
        self.assertEqual(json.get(Fields.merchant_id.value), self.api.key)
        self.assertEqual(req.route, Route.PARTNER_API)


class TestReport(GatewaySetup):

    def test_to_dict(self):
        req = Report()
        self.assertIsNotNone(req)
        json = req.to_dict()
        self.assertIsNotNone(json.get(Fields.report_from_date.value))
        self.assertIsNotNone(json.get(Fields.report_to_date.value))
        self.assertEqual(
            json.get(Fields.merchant.value).get(Fields.merchant_id.value),
            self.api.key)
        self.assertEqual(json.get(Fields.report_type.value),
                         Report.ReportType.transactionReport)
