from gateway import ThreeDSecure, ExternalThreeds, \
    Exemptions, DeviceFingerprint, SdkDetails
from test.test_common import GatewaySetup


class TestThreeDSecure(GatewaySetup):

    def test_to_dict(self):
        three_d_secure = ThreeDSecure(
            challenge_indicator="01",
            challenge_window_size="05",
        )
        actual = three_d_secure.to_dict()
        expected = {
            "challengeIndicator": "01",
            "challengeWindowSize": "05",
        }

        self.assertDictEqual(actual, expected)


class TestExternalThreeds(GatewaySetup):

    def test_to_dict(self):
        external_threeds = ExternalThreeds(
            eci_code="06",
            three_ds_status="Y",
            acs_txn_id="foo",
            ds_txn_id="bar",
            three_ds_server_txn_id="baz",
            three_ds_version="2.1.0",
            authentication_value="qux",
            xid="quux",
        )
        actual = external_threeds.to_dict()
        expected = {
            "eciCode": "06",
            "threedsStatus": "Y",
            "acsTransactionId": "foo",
            "dsTransactionId": "bar",
            "threedsServerTransactionId": "baz",
            "threedsVersion": "2.1.0",
            "authenticationValue": "qux",
            "xid": "quux",
        }
        self.assertDictEqual(actual, expected)


class TestDeviceFingerPrint(GatewaySetup):

    def test_to_dict(self):
        device_finger_print = DeviceFingerprint(
            timezone="330",
            browser_color_depth="24",
            browser_language="en-GB",
            browser_screen_height="1080",
            browser_screen_width="1920",
            os="windows",
            browser_accept_header="foo",
            user_agent="bar",
            browser_javascript_enabled=False,
            browser_java_enabled=True,
            accept_content="baz",
            browser_ip="192.1.1.1",
        )
        actual = device_finger_print.to_dict()
        expected = {
            "timezone": "330",
            "browserColorDepth": "24",
            "browserLanguage": "en-GB",
            "browserScreenHeight": "1080",
            "browserScreenWidth": "1920",
            "os": "windows",
            "browserAcceptHeader": "foo",
            "userAgent": "bar",
            "browserJavaEnabled": True,
            "acceptContent": "baz",
            "browserIP": "192.1.1.1",
        }
        self.assertDictEqual(actual, expected)


class TestExceptions(GatewaySetup):

    def test_to_dict(self):
        exemptions = Exemptions(
            low_value=True,
            tra=True,
            trusted_beneficiary=True,
            secure_corporate_payment=True,
            delegated_authentication=True,
            recurring_mit_exemption_same_amount=True,
            recurring_mit_exemption_other=True,
            vmid="12345",
        )
        actual = exemptions.to_dict()
        expected = {
            "lowValue": True,
            "tra": True,
            "trustedBeneficiary": True,
            "secureCorporatePayment": True,
            "delegatedAuthentication": True,
            "recurringMITExemptionSameAmount": True,
            "recurringMITExemptionOther": True,
            "vmid": "12345",
        }
        self.assertDictEqual(actual, expected)


class TestSdkDetails(GatewaySetup):

    def test_to_dict(self):
        sdk_details = SdkDetails(
            sdk_app_id="foo",
            sdk_enc_data="bar",
            sdk_ephem_pub_key="baz",
            sdk_max_timeout="60",
            sdk_reference_number="qux",
            sdk_trans_id="quux",
        )
        actual = sdk_details.to_dict()
        expected = {
            "sdkAppID": "foo",
            "sdkEncData": "bar",
            "sdkEphemPubKey": "baz",
            "sdkMaxTimeout": "60",
            "sdkReferenceNumber": "qux",
            "sdkTransID": "quux",
        }
        self.assertDictEqual(actual, expected)
