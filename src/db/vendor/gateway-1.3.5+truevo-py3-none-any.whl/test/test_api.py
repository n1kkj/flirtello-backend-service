from urllib.parse import urlparse

import gateway.api as _api
from gateway.common import Endpoints
from gateway.exceptions import GatewayError
from test.test_common import GatewaySetup


class test_crypt(GatewaySetup):

    def test_api_endpoints(self):
        api = _api.Api(self.key, self.token, self.cert)
        self.assertEqual(
            Endpoints.test.value,
            'https://stagapi.my.truevo.com')
        self.assertEqual(api.endpoint, Endpoints.test.value)
        api.live()
        self.assertEqual(
            Endpoints.live.value,
            'https://api.my.truevo.com')
        self.assertEqual(api.endpoint, Endpoints.live.value)

    def test_api_init(self):
        _api.configure(self.key, self.token, self.cert)
        api = _api.Api.get()
        self.assertEqual(api.token, self.token)

    def test_valid_endpoints(self):
        parsed_url = map(lambda x: urlparse(x), [
            Endpoints.live.value, Endpoints.test.value])
        self.assertTrue(all(map(
            lambda x: all([x.netloc, x.scheme]), parsed_url)))


class test_api(GatewaySetup):

    def test_prepare_payload(self):
        api = _api.Api(self.key, self.token, self.cert)
        actual = api._prepare_payload(b'{"merchantId": "foo"}', "en")
        expected = ["payLoad", "apiKey", "lang"]
        self.assertCountEqual(list(actual.keys()), expected)

    def test_prepare_payload_when_empty_data(self):
        api = _api.Api(self.key, self.token, self.cert)
        with self.assertRaises(GatewayError):
            api._prepare_payload(b'', "en")

    def test_prepare_payload_when_null_data(self):
        api = _api.Api(self.key, self.token, self.cert)
        actual = api._prepare_payload(b'null', "en")
        self.assertIsNone(actual)

    def test_send_when_invalid_object(self):
        class Temp:
            pass
        api = _api.Api(self.key, self.token, self.cert)
        with self.assertRaises(AttributeError):
            api.send(Temp())

    def test_send_when_empty_data(self):
        class Temp:
            def get_request_dict(self):
                return {
                    "data": "",
                    "method": "foo",
                    "route": "bar",
                    "lang": "baz",
                }

            def get_header_dict(self):
                return {}
        api = _api.Api(self.key, self.token, self.cert)
        with self.assertRaises(GatewayError):
            api.send(Temp())
