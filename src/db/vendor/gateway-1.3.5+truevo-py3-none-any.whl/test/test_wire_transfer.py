from gateway import SaveWireTransferBankDetails, Currency, BankDetails, \
    AccountHolder, UpdateWireTransferBankDetails, \
    GetWireTransferBankDetails, DeleteWireTransferBankDetails, \
    ApproveWireTransferTransaction
from gateway.common import Fields, Route
from gateway.request import HttpMethod
from test.test_common import GatewaySetup

bank_details = BankDetails('test', 'test', sort_code="sort code", bic="bic",
                           iban="iban")
account_holder = AccountHolder('test', 'test')
REGISTRATION_ID = 'REG123'


class TestSaveWireTransferBankDetails(GatewaySetup):

    def test_to_dict(self):
        req = SaveWireTransferBankDetails(Currency.EUR, bank_details,
                                          account_holder)
        test_details(self, req)
        self.assertEqual(req.route, '/' + self.api.key + Route.WIRE_TRANSFER)


class TestUpdateWireTransferBankDetails(TestSaveWireTransferBankDetails):

    def test_details(self):
        req = UpdateWireTransferBankDetails(REGISTRATION_ID, Currency.EUR,
                                            bank_details,
                                            account_holder, default=False,
                                            european=False,
                                            description=None, api=None)
        test_details(self, req)
        self.assertEqual(req.route,
                         '/' + self.api.key + Route.WIRE_TRANSFER +
                         '/' + REGISTRATION_ID)


class TestGetWireTransferBankDetails(GatewaySetup):

    def test_details(self):
        req = GetWireTransferBankDetails(REGISTRATION_ID)
        self.assertIsNotNone(req)
        self.assertEqual(req.method, HttpMethod.get.value)
        self.assertEqual(req.route,
                         "/" + self.api.key + Route.WIRE_TRANSFER +
                         "/" + REGISTRATION_ID)


class TestDeleteWireTransferBankDetails(GatewaySetup):

    def test_details(self):
        req = DeleteWireTransferBankDetails(REGISTRATION_ID)
        self.assertIsNotNone(req)
        self.assertEqual(req.method, HttpMethod.delete.value)
        self.assertEqual(req.route,
                         "/" + self.api.key + Route.WIRE_TRANSFER +
                         "/" + REGISTRATION_ID)


class TestApproveWireTransferTransaction(GatewaySetup):

    def test_details(self):
        txn_reference = 'REF123'
        req = ApproveWireTransferTransaction(txn_reference)
        self.assertIsNotNone(req)
        self.assertEqual(req.method, HttpMethod.post.value)
        self.assertEqual(req.route,
                         "/" + self.api.key + Route.WIRE_TRANSFER +
                         "/transaction/" + txn_reference)


def test_details(self, req):
    self.assertIsNotNone(req)
    json = req.to_dict()
    self.assertIsNotNone(json.get(Fields.account_holder.value))
    self.assertFalse(json.get(Fields.default.value))
    self.assertFalse(json.get(Fields.european.value))
    self.assertEqual(json.get(Fields.merchant_id.value), self.api.key)
    self.assertEqual(json.get(Fields.account_holder.value), account_holder)
    self.assertEqual(json.get(Fields.bank.value), bank_details)
