from gateway import Events, CreateWebhook, \
    WebhookStatus, DeleteWebhook, UpdateWebhook
from gateway.common import Fields
from test.test_common import GatewaySetup


class TestWebhook(GatewaySetup):
    pass


class TestCreateWebhook(TestWebhook):

    def test_to_dict(self):
        events = [Events.chargeback, Events.payment]
        req = CreateWebhook(endpoint='https://test.com', events=events)
        self.assertIsNotNone(req)
        json = req.to_dict()
        self.assertIsNotNone(json.get('webhook').get('url'))
        self.assertEqual(json.get('webhook').get('events'),
                         "chargeback,payment")
        self.assertEqual(json.get(Fields.merchant_id.value), self.api.key)


class TestWebhookStatus(TestWebhook):

    def test_to_dict(self):
        webhook_status = WebhookStatus("foo")
        actual = webhook_status.to_dict()
        expected = {
            "merchantID": "GIT210317001",
            "webhook": {
                "webhookId": "foo",
            }
        }
        self.assertDictEqual(actual, expected)


class TestDeleteWebhook(TestWebhook):

    def test_to_dict(self):
        delete_webhook = DeleteWebhook("foo")
        actual = delete_webhook.to_dict()
        expected = {
            "merchantID": "GIT210317001",
            "webhook": {
                "webhookId": "foo",
                "status": "inactive"
            }
        }
        self.assertDictEqual(actual, expected)


class TestUpdateWebhook(TestWebhook):

    def test_to_dict(self):
        events = [Events.chargeback, Events.payment]
        update_webhook = UpdateWebhook("foo", "bar", events)
        actual = update_webhook.to_dict()
        expected = {
            "merchantID": "GIT210317001",
            "webhook": {
                "webhookId": "foo",
                "url": "bar",
                "events": "chargeback,payment",
            }
        }
        self.assertDictEqual(actual, expected)
