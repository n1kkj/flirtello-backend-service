from gateway import Txn, DeactivateSubscriptionPlan, \
    GetSubscriptionPlanDetails, UpdateSubscriptionPlan, Installments, \
    Currency, CreatePlan
from gateway.common import ApiType, Route, Fields
from gateway.request import HttpMethod
from test.test_common import GatewaySetup

PLAN_ID = 'PLAN123456'
INSTALLMENT = Installments(total_installments=3, amount=10,
                           period="DAY", types="TRIAL",
                           currency_code=Currency.EUR,
                           frequency=1, sequence=2)


class TestSubscriptionPlan(GatewaySetup):

    def setUp(self):
        super().setUp()
        self.txn = Txn()


class TestCreatePlan(TestSubscriptionPlan):

    def test_to_dict(self):
        testcode = 'TESTCODE'
        req = CreatePlan(name='test_plan', code=testcode,
                         installements=INSTALLMENT)
        json = req.to_dict()
        self.assertEqual(json.get('installments'), [INSTALLMENT])
        self.assertEqual(json.get(Fields.code.value), testcode)
        self.assertEqual(req.route, '/' + self.api.key + Route.PLANS)
        req.add_installment(installment=INSTALLMENT)
        with self.assertRaises(ValueError):
            req.add_installment([])


class TestUpdateSubscriptionPlan(TestSubscriptionPlan):

    def test_details(self):
        req = UpdateSubscriptionPlan(plan_id=PLAN_ID, name='update_test_plan',
                                     installements=INSTALLMENT)
        test_api_details(self, req, ApiType.UPDATE_PLAN, HttpMethod.put.value)
        self.assertEqual(req.to_dict().get('installments'), [INSTALLMENT])


class TestGetSubscriptionPlanDetails(TestSubscriptionPlan):

    def test_details(self):
        req = GetSubscriptionPlanDetails(plan_id=PLAN_ID)
        test_api_details(self, req, ApiType.GET_PLAN_DETAILS,
                         HttpMethod.get.value)


class TestDeactivateSubscriptionPlan(TestSubscriptionPlan):

    def test_details(self):
        req = DeactivateSubscriptionPlan(plan_id=PLAN_ID)
        test_api_details(self, req, ApiType.DEACTIVATE_PLAN,
                         HttpMethod.delete.value)


def test_api_details(self, req, signature, method_name):
    self.assertIsNotNone(req)
    self.assertEqual(req.signature, signature)
    self.assertEqual(req.method, method_name)
    self.assertEqual(req.txn_id, PLAN_ID)
    self.assertEqual(req.route,
                     '/' + self.api.key + Route.PLANS + '/' + PLAN_ID)
