from unittest import TestCase

from gateway import utils


class test_utils(TestCase):

    def test_sanitize_url(self):
        CASES = (
            ("//google.com", "https://google.com"),
            ("bing.com", "https://bing.com"),
            ("://duckduckgo.com", "https://duckduckgo.com"),
            ("yahoo.com/search/", "https://yahoo.com/search/"),
            ("baidu.ch?q=searchfield", "https://baidu.ch?q=searchfield"),
        )
        for test_value, expected_output in CASES:
            self.assertEqual(utils.sanitize_url(test_value), expected_output)


class test_validator(TestCase):

    def test_validator_empty(self):
        CASES = (
            (0, True),
            (0.0, True),
            (False, True),
            (" ", True),
            (1, False),
            (True, False),
            (" s", False),
        )
        for test_value, expected_output in CASES:
            param = {
                "expr": utils.Validator.empty(test_value),
                "msg": test_value
            }
            (self.assertTrue(**param) if expected_output
             else self.assertFalse(**param))

    def test_validator_amount(self):
        CASES = (
            (0, True),
            (0.0, True),
            (123, True),
            (0.1234, True),
            ("100.00", True),
            ("100,00", False),
            ("100 00", False),
            ("+1234567890.1234", True),
            ("+1234567890.12345", False),
        )
        for test_value, expected_output in CASES:
            self.assertEqual(
                utils.Validator.amount(test_value),
                expected_output,
                msg=test_value
            )

    def test_validator_item_amount(self):
        CASES = (
            (0, True),
            (0.0, True),
            (123, True),
            (123, True),
            (0.1234, True),
            ("100.00", True),
            ("100,00", False),
            ("100 00", False),
            ("+1234567890.1234", True),
            ("+1234567890.12345", False),
            (-123, True),
            (-123, True),
            (-0.1234, True),
            ("-100.00", True),
            ("-1234567890.1234", True),
            ("-1234567890.12345", False),
        )
        for test_value, expected_output in CASES:
            param = {
                "expr": utils.Validator.item_amount(test_value),
                "msg": test_value
            }
            (self.assertTrue(**param) if expected_output
             else self.assertFalse(**param))

    def test_validator_email(self):
        CASES = (
            ("name@domain.com", True),
            ("check.dot@domain.com", True),
            ("name@domain.tld", True),
            ("____@domain.com", True),
            ("name@domain.invalidtld", False),
            ("normalstring", False),
            (".leadingdot@domain.com", False),
            ("trailingdot.@domain.com", False),
            ("name@1.22.333.4444", False),
            ("notld@domain", False),
            ("aいuえo@nouni.code", False),
        )
        for test_value, expected_output in CASES:
            param = {
                "expr": utils.Validator.email(test_value),
                "msg": test_value
            }
            (self.assertTrue(**param) if expected_output
             else self.assertFalse(**param))

    def test_validator_number_length(self):
        CASES = (
            ((100, 4), True),
            ((1234, 4), True),
            ((1234566890, 10), True),
            ((12345, 4), False),
            (("92 1", 4), False),
            (("12.9", 4), False),
            (("1234566890", 10), True),
        )
        for test_value, expected_output in CASES:
            param = {
                "expr": utils.Validator.number_lenth(*test_value),
                "msg": test_value
            }
            (self.assertTrue(**param) if expected_output
             else self.assertFalse(**param))

    def test_validator_number_space(self):
        CASES = (
            (100, True),
            (1234, True),
            (1234566890, True),
            ("92 1", True),
            (" ", False),
            ("1234566890", True),
        )
        for test_value, expected_output in CASES:
            param = {
                "expr": utils.Validator.number_space(test_value),
                "msg": test_value
            }
            (self.assertTrue(**param) if expected_output
             else self.assertFalse(**param))
