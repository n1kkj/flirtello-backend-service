import logging


class Log:

    api_key = None
    logger = logging.getLogger("debug_logger")
    logger.setLevel(logging.INFO)
    handler = logging.StreamHandler()
    format = "%(levelname)s [%(asctime)s] " \
        "(%(filename)s:%(lineno)d) - %(api_key)s - %(message)s"
    formatter = logging.Formatter(format)
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.propagate = False

    DEBUG = logging.LoggerAdapter(
        logger,
        extra={"api_key": api_key}
    ).debug

    @classmethod
    def update_api_key(cls, api_key):
        cls.api_key = api_key
        cls.DEBUG = logging.LoggerAdapter(
            cls.logger,
            extra={"api_key": api_key}
        ).debug

    @classmethod
    def enable_debug(cls):
        cls.logger.setLevel(logging.DEBUG)
        cls.DEBUG = logging.LoggerAdapter(
            cls.logger,
            extra={"api_key": cls.api_key}
        ).debug


def enable_debug():
    Log.enable_debug()
