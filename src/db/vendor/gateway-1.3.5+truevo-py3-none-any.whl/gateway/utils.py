import re
from pytz import datetime, timezone

URL_MAXLENGTH = 500

AMOUNT_MAXLENGTH = 16

ALLSPECIAL_MAXLENGTH = 255


def sanitize_url(url):
    """Sanitizes URL"""

    DEFAULT_SCHEMA = "https"

    if url.startswith('//'):
        return "%s:%s" % (DEFAULT_SCHEMA, url)
    matches = re.findall(r"^(([a-z0-9]+)?(:\/\/|:\/))?(.*)$", url)
    return "%s://%s" % (DEFAULT_SCHEMA, matches[0][3])


def get_time_for_tz(tzlist):
    """Get datetime for timezones"""

    t_now = datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc)
    return map(lambda tz: t_now.astimezone(timezone(tz)), tzlist)


def ymd_to_datetime(dt):
    """Convert string to Y-m-d format. Ignores if it is datetime"""

    return dt if isinstance(
            dt, datetime.datetime
            ) else datetime.datetime.strptime(dt, '%Y-%m-%d')


def merge_dicts(dest, *dicts, allow_empty=True):
    merged = dest or {}
    for d in dicts:
        for k, v in d.items():
            if isinstance(v, dict):
                node = merged.setdefault(k, {})
                merged[k] = merge_dicts(node, v)
            else:
                if not Validator.empty(v) or allow_empty:
                    merged[k] = v
    return merged


class Validator:
    """Validator utility class"""

    @staticmethod
    def empty(value):
        return (
                (True if not value else False)
                or bool(re.match(r"^\s*$", str(value)))
                )

    @staticmethod
    def amount(value):
        """Check transaction amount"""
        return (
                bool(re.match(r"^[+]?[\d]+[.]?[\d]{0,4}$", str(value)))
                and len(str(value)) <= AMOUNT_MAXLENGTH
                )

    @staticmethod
    def item_amount(value):
        """Check order item amount"""
        return (
                bool(re.match(r"^[-+]?[\d]+[.]?[\d]{0,4}$", str(value)))
                and len(str(value)) <= AMOUNT_MAXLENGTH
                )

    @staticmethod
    def email(value):
        """Check email address"""
        return bool(
                re.match(
                    r"^[_a-z0-9-]+([.][_a-z0-9-]+)*@[a-z0-9-]+"
                    r"([.][a-z0-9-]+)*([.][a-z]{2,4})$",
                    value
                    )
                )

    @staticmethod
    def number_lenth(value, maxlength):
        """Check number length"""
        return (
                bool(re.match(r"^[\d]+$", str(value)))
                and len(str(value)) <= maxlength
                )

    @staticmethod
    def number_space(value):
        """Check number with spaces"""
        return (
                bool(re.match(r"^[\d ]+$", str(value)))
                and not Validator.empty(value)
                )
