from base64 import b64encode
from hashlib import sha256 as _hashlib_sha256
from hmac import new as _hmac_new

from . import version
from .api import Api
from .common import GatewayObject, CommonType
from .exceptions import GatewayError
from .utils import Validator, get_time_for_tz
from .api_resources import Language
from .log import Log


class HttpMethod(CommonType):
    """HTTP Methods support by gateway"""

    """Default"""
    default = "post"

    """POST"""
    post = "post"

    """UPDATE"""
    update = "update"

    """DELETE"""
    delete = "delete"

    """GET"""
    get = "get"

    """put"""
    put = "put"


class Request(GatewayObject):
    """Base request class
    """

    _lang = Language.en

    def __init__(self, api=None):
        self.set_api(api)

    def set_api(self, api):
        self.api = api or Api.get()

    def get_request_dict(self):
        return {
            "name": self.name,
            "data": self.encode(),
            "method": self.method,
            "route": self.route,
            "lang": self.lang,
        }

    @property
    def lang(self):
        return self._lang.value

    def setLang(self, lang):
        self._lang = Language(lang)
        return self

    def send(self):
        if getattr(self, 'response', None):
            raise GatewayError("%s request already sent" % self.name)
        self.response = self.api.send(self)
        return self.response

    def __repr__(self):
        return "<[%s] request object at %s>" % (self.name, hex(id(self)))

    @property
    def name(self):
        return self._name

    @property
    def method(self):
        try:
            return self._method
        except AttributeError:
            return HttpMethod.default.value

    @property
    def route(self):
        try:
            return self._route
        except AttributeError:
            return ""


class AuthTokenRequest(Request):

    def get_headers_dict(self):
        if Validator.empty(self.signature):
            raise GatewayError("Empty request signature")
        t_ist, t_gmt = get_time_for_tz(["Asia/Kolkata", "GMT"])
        msg = "+".join([
            self.signature,
            "/pArTnErApI",
            t_ist.strftime("%H%M%S%d%m%Y"),
            str(self.txn_id)])
        Log.DEBUG("HMAC msg: %s", msg)
        hmac_msg = "hmac " + ":".join([
            self.api.key,
            str(self.txn_id),
            b64encode(
                _hmac_new(
                    self.api.token.encode(),
                    msg.encode(),
                    _hashlib_sha256).digest()
            ).decode()])
        wrapper_verion = version.__version__.split('+')[0]
        return {
            "Authorization": hmac_msg,
            "dateHeader": t_gmt.strftime("%a, %d %b %Y %H:%M:%S %Z"),
            "X-SDK-Version": "python-wrapper-" + wrapper_verion
        }

    @property
    def txn_id(self):
        return str(self._txn_id)

    @property
    def signature(self):
        return str(self._signature)
