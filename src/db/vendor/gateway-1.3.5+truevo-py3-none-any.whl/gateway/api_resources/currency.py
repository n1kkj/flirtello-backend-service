from ..common import CommonType


class Currency(CommonType):
    """Currencies (ISO4217) supported by gateway"""

    """UAE Dirham"""
    AED = "AED"

    """Afghani"""
    AFN = "AFN"

    """Lek"""
    ALL = "ALL"

    """Armenian Dram"""
    AMD = "AMD"

    """Netherlands Antillean Guilder"""
    ANG = "ANG"

    """Kwanza"""
    AOA = "AOA"

    """Argentine Peso"""
    ARS = "ARS"

    """Australian Dollar"""
    AUD = "AUD"

    """Aruban Florin"""
    AWG = "AWG"

    """Azerbaijanian Manat"""
    AZN = "AZN"

    """Convertible Mark"""
    BAM = "BAM"

    """Barbados Dollar"""
    BBD = "BBD"

    """Taka"""
    BDT = "BDT"

    """Bulgarian Lev"""
    BGN = "BGN"

    """Bahraini Dinar"""
    BHD = "BHD"

    """Burundi Franc"""
    BIF = "BIF"

    """Bermudian Dollar"""
    BMD = "BMD"

    """Brunei Dollar"""
    BND = "BND"

    """Boliviano"""
    BOB = "BOB"

    """Mvdol"""
    BOV = "BOV"

    """Brazilian Real"""
    BRL = "BRL"

    """Bahamian Dollar"""
    BSD = "BSD"

    """Ngultrum"""
    BTN = "BTN"

    """Pula"""
    BWP = "BWP"

    """Belarussian Ruble"""
    BYN = "BYN"

    """Belize Dollar"""
    BZD = "BZD"

    """Canadian Dollar"""
    CAD = "CAD"

    """Congolese Franc"""
    CDF = "CDF"

    """WIR Euro"""
    CHE = "CHE"

    """Swiss Franc"""
    CHF = "CHF"

    """WIR Franc"""
    CHW = "CHW"

    """Unidad de Fomento"""
    CLF = "CLF"

    """Chilean Peso"""
    CLP = "CLP"

    """Yuan Renminbi"""
    CNY = "CNY"

    """Colombian Peso"""
    COP = "COP"

    """Unidad de Valor Real"""
    COU = "COU"

    """Costa Rican Colon"""
    CRC = "CRC"

    """Peso Convertible"""
    CUC = "CUC"

    """Cuban Peso"""
    CUP = "CUP"

    """Cabo Verde Escudo"""
    CVE = "CVE"

    """Czech Koruna"""
    CZK = "CZK"

    """Djibouti Franc"""
    DJF = "DJF"

    """Danish Krone"""
    DKK = "DKK"

    """Dominican Peso"""
    DOP = "DOP"

    """Algerian Dinar"""
    DZD = "DZD"

    """Egyptian Pound"""
    EGP = "EGP"

    """Nakfa"""
    ERN = "ERN"

    """Ethiopian Birr"""
    ETB = "ETB"

    """Euro"""
    EUR = "EUR"

    """Fiji Dollar"""
    FJD = "FJD"

    """Falkland Islands Pound"""
    FKP = "FKP"

    """Pound Sterling"""
    GBP = "GBP"

    """Lari"""
    GEL = "GEL"

    """Ghana Cedi"""
    GHS = "GHS"

    """Gibraltar Pound"""
    GIP = "GIP"

    """Dalasi"""
    GMD = "GMD"

    """Guinea Franc"""
    GNF = "GNF"

    """Quetzal"""
    GTQ = "GTQ"

    """Guyana Dollar"""
    GYD = "GYD"

    """Hong Kong Dollar"""
    HKD = "HKD"

    """Lempira"""
    HNL = "HNL"

    """Gourde"""
    HTG = "HTG"

    """Forint"""
    HUF = "HUF"

    """Rupiah"""
    IDR = "IDR"

    """New Israeli Sheqel"""
    ILS = "ILS"

    """Indian Rupee"""
    INR = "INR"

    """Iraqi Dinar"""
    IQD = "IQD"

    """Iranian Rial"""
    IRR = "IRR"

    """Iceland Krona"""
    ISK = "ISK"

    """Jamaican Dollar"""
    JMD = "JMD"

    """Jordanian Dinar"""
    JOD = "JOD"

    """Yen"""
    JPY = "JPY"

    """Kenyan Shilling"""
    KES = "KES"

    """Som"""
    KGS = "KGS"

    """Riel"""
    KHR = "KHR"

    """Comoro Franc"""
    KMF = "KMF"

    """North Korean Won"""
    KPW = "KPW"

    """Won"""
    KRW = "KRW"

    """Kuwaiti Dinar"""
    KWD = "KWD"

    """Cayman Islands Dollar"""
    KYD = "KYD"

    """Tenge"""
    KZT = "KZT"

    """Kip"""
    LAK = "LAK"

    """Lebanese Pound"""
    LBP = "LBP"

    """Sri Lanka Rupee"""
    LKR = "LKR"

    """Liberian Dollar"""
    LRD = "LRD"

    """Loti"""
    LSL = "LSL"

    """Libyan Dinar"""
    LYD = "LYD"

    """Moroccan Dirham"""
    MAD = "MAD"

    """Moldovan Leu"""
    MDL = "MDL"

    """Malagasy Ariary"""
    MGA = "MGA"

    """Denar"""
    MKD = "MKD"

    """Kyat"""
    MMK = "MMK"

    """Tugrik"""
    MNT = "MNT"

    """Pataca"""
    MOP = "MOP"

    """Ouguiya"""
    MRU = "MRU"

    """Mauritius Rupee"""
    MUR = "MUR"

    """Rufiyaa"""
    MVR = "MVR"

    """Kwacha"""
    MWK = "MWK"

    """Mexican Peso"""
    MXN = "MXN"

    """Mexican Unidad de Inversion (UDI)"""
    MXV = "MXV"

    """Malaysian Ringgit"""
    MYR = "MYR"

    """Mozambique Metical"""
    MZN = "MZN"

    """Namibia Dollar"""
    NAD = "NAD"

    """Naira"""
    NGN = "NGN"

    """Cordoba Oro"""
    NIO = "NIO"

    """Norwegian Krone"""
    NOK = "NOK"

    """Nepalese Rupee"""
    NPR = "NPR"

    """New Zealand Dollar"""
    NZD = "NZD"

    """Rial Omani"""
    OMR = "OMR"

    """Balboa"""
    PAB = "PAB"

    """Nuevo Sol"""
    PEN = "PEN"

    """Kina"""
    PGK = "PGK"

    """Philippine Peso"""
    PHP = "PHP"

    """Pakistan Rupee"""
    PKR = "PKR"

    """Zloty"""
    PLN = "PLN"

    """Guarani"""
    PYG = "PYG"

    """Qatari Rial"""
    QAR = "QAR"

    """Romanian Leu"""
    RON = "RON"

    """Serbian Dinar"""
    RSD = "RSD"

    """Russian Ruble"""
    RUB = "RUB"

    """Rwanda Franc"""
    RWF = "RWF"

    """Saudi Riyal"""
    SAR = "SAR"

    """Solomon Islands Dollar"""
    SBD = "SBD"

    """Seychelles Rupee"""
    SCR = "SCR"

    """Sudanese Pound"""
    SDG = "SDG"

    """Swedish Krona"""
    SEK = "SEK"

    """Singapore Dollar"""
    SGD = "SGD"

    """Saint Helena Pound"""
    SHP = "SHP"

    """Leone"""
    SLE = "SLE"

    """Somali Shilling"""
    SOS = "SOS"

    """Surinam Dollar"""
    SRD = "SRD"

    """South Sudanese Pound"""
    SSP = "SSP"

    """Dobra"""
    STN = "STN"

    """El Salvador Colon"""
    SVC = "SVC"

    """Syrian Pound"""
    SYP = "SYP"

    """Lilangeni"""
    SZL = "SZL"

    """Baht"""
    THB = "THB"

    """Somoni"""
    TJS = "TJS"

    """Turkmenistan New Manat"""
    TMT = "TMT"

    """Tunisian Dinar"""
    TND = "TND"

    """Pa’anga"""
    TOP = "TOP"

    """Turkish Lira"""
    TRY = "TRY"

    """Trinidad and Tobago Dollar"""
    TTD = "TTD"

    """New Taiwan Dollar"""
    TWD = "TWD"

    """Tanzanian Shilling"""
    TZS = "TZS"

    """Hryvnia"""
    UAH = "UAH"

    """Uganda Shilling"""
    UGX = "UGX"

    """US Dollar"""
    USD = "USD"

    """US Dollar (Next day)"""
    USN = "USN"

    """Uruguay Peso en Unidades Indexadas (URUIURUI)"""
    UYI = "UYI"

    """Peso Uruguayo"""
    UYU = "UYU"

    """Uzbekistan Sum"""
    UZS = "UZS"

    """Bolivar"""
    VED = "VED"

    """Bolivar"""
    VEF = "VEF"

    """Dong"""
    VND = "VND"

    """Vatu"""
    VUV = "VUV"

    """Tala"""
    WST = "WST"

    """CFA Franc BEAC"""
    XAF = "XAF"

    """East Caribbean Dollar"""
    XCD = "XCD"

    """SDR (Special Drawing Right)"""
    XDR = "XDR"

    """CFA Franc BCEAO"""
    XOF = "XOF"

    """CFP Franc"""
    XPF = "XPF"

    """Sucre"""
    XSU = "XSU"

    """ADB Unit of Account"""
    XUA = "XUA"

    """Yemeni Rial"""
    YER = "YER"

    """Rand"""
    ZAR = "ZAR"

    """Zambian Kwacha"""
    ZMW = "ZMW"

    """Zimbabwe Dollar"""
    ZWL = "ZWL"
