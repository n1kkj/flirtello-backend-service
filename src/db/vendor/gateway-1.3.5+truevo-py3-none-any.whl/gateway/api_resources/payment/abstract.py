from uuid import uuid4

from ...common import CommonType, UIDType, GatewayObject
from .. import Currency


class TypeInfo(CommonType):
    pass


class WHPPInfo(GatewayObject):
    pass


class Txn(UIDType):

    def __init__(self, uid=None, amount=None, currency=None):
        super(Txn, self).__init__(uid)
        if not self.uid:
            self.uid = uuid4()
        self.amount = amount if amount else 0
        self.currency = Currency(currency) if currency else None


class Token(UIDType):
    pass
