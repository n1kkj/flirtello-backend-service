from ...utils import merge_dicts
from ...common import Fields
from .abstract import WHPPInfo, TypeInfo, Token


class CardTypes(TypeInfo):
    """Card types
    """

    AmericanExpress = "AmericanExpress"
    AstropayCard = "AstropayCard"
    CARTASI = "CARTASI"
    CARTEBLEUE = "CARTEBLEUE"
    CMRFalabella = "CMRFalabella"
    Cordial = "Cordial"
    DANKORT = "DANKORT"
    DinersClub = "DinersClub"
    DISCOVER = "DISCOVER"
    HIPERCARD = "HIPERCARD"
    JCB = "JCB"
    LASER = "LASER"
    MasterCard = "MasterCard"
    Maestro = "Maestro"
    MaestroUK = "MaestroUK"
    POSTEPAY = "POSTEPAY"
    Presto = "Presto"
    Rupay = "Rupay"
    SOLO = "SOLO"
    UNIONPAY = "UNIONPAY"
    VisaCard = "VisaCard"
    VISAELECTRON = "VISAELECTRON"
    VPAY = "VPAY"


class CardDetails(WHPPInfo):
    """Card details required for WHPP
    """

    def __init__(self, opts=None, **kwargs):
        """Either a token or card_number, name, cvv, expiry_month,
           expiry_year, save
        """
        kwargs = merge_dicts(opts or {}, kwargs)
        self.token = Token(kwargs.get("token"))
        self.number = kwargs.get("number")
        self.name = kwargs.get("name")
        self.cvv = kwargs.get("cvv")
        self.expiry_year = kwargs.get("expiry_year")
        self.expiry_month = kwargs.get("expiry_month")
        self.save = kwargs.get("save", False)
        self.card_type = kwargs.get("card_type")
        self.enc_card_number = kwargs.get("enc_card_number")
        self.enc_algorithm = kwargs.get("enc_algorithm")
        self.key_sequence_number = kwargs.get("key_sequence_number")
        self.acquirer = kwargs.get("acquirer")

    def to_dict(self):
        if self.token.uid is not None:
            return merge_dicts(
                {Fields.card_token.value: self.token},
                {Fields.card_cvv.value: self.cvv},
                allow_empty=False)
        data = merge_dicts(
            {},
            {
                Fields.card_number.value: self.number,
                Fields.card_name.value: self.name,
                Fields.card_cvv.value: self.cvv,
                Fields.card_year.value: self.expiry_year,
                Fields.card_month.value: self.expiry_month,
                Fields.card_save.value: bool(self.save),
                Fields.enc_card_number.value: self.enc_card_number,
                Fields.enc_algorithm.value: self.enc_algorithm,
                Fields.key_sequence_number.value: self.key_sequence_number,
                Fields.acquirer.value: self.acquirer,
            },
            allow_empty=False)
        if self.card_type:
            data[Fields.card_type.value] = self.card_type
        return data
