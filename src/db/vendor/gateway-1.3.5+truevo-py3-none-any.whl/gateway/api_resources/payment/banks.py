from .abstract import TypeInfo
from ...common import GatewayObject, Fields
from ...utils import merge_dicts


class BankTypes(TypeInfo):
    """Bank types
    """

    ABN_AMRO = "ABNANL2A"
    ASNBANK = "ASN Bank"
    ING = "ING_BANK"
    BUNQ_BANK = "BUNQ_BANK"
    KNAB = "knab"
    INGBNL2A = "INGBNL2A"
    SNSBANK = "SNS Bank"
    RABOBANK = "Rabobank"
    REGIOBANK = "RegioBank"
    VAN_LANSCHOT_BANKIERS = "VAN_LANSCHOT_BANKIERS"
    TRIODOSBANK = "Triodos Bank"


class BankDetails(GatewayObject):
    def __init__(self, name=None, address=None, opts=None, **kwargs):
        config = merge_dicts(opts or {}, kwargs)
        self._name = "Bank Details"
        self.__name = name
        self.__address = address
        self._account_number = config.get("account_number")
        self._bic = config.get("bic")
        self._iban = config.get("iban")
        self._sort_code = config.get("sort_code")
        self._payment_token = config.get("payment_token")
        self._holder = config.get("holder")

    def to_dict(self):
        return merge_dicts(
            {},
            {
                Fields.name.value: self.__name,
                Fields.address.value: self.__address,
                Fields.bic.value: self._bic,
                Fields.account_number.value: self._account_number,
                Fields.iban.value: self._iban,
                Fields.sort_code.value: self._sort_code,
                Fields.payment_token.value: self._payment_token,
                Fields.holder.value: self._holder
            },
            allow_empty=False
        )
