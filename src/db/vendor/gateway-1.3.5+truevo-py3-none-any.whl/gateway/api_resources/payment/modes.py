from ...common import CommonType, Fields, GatewayObject
from .abstract import WHPPInfo, TypeInfo
from .banks import BankTypes, BankDetails
from .cards import CardTypes, CardDetails


class Modes(CommonType):
    """All supported Payment methods
    """

    HPP = (None, False, False)
    APPLE_PAY = ("APPLE_PAY", False, False)
    ASTROPAY = ("ASTROPAY", False, False)
    ASTROPAYCARD = ("ASTROPAYCARD", False, False)
    BANAMEX = ("BANAMEX", False, False)
    BCMC = ("BCMC", False, False)
    BOKU = ("BOKU", False, False)
    BOLETO = ("BOLETO", False, False)
    CHINAUNIONPAY = ("CHINAUNIONPAY", False, False)
    CREDITCARD = ("CreditCard", CardTypes, CardDetails)
    DEBITCARD = ("DebitCard", CardTypes, CardDetails)
    EPS = ("EPS", False, False)
    GIROPAY = ("GIROPAY", False, BankDetails)
    IDEAL = ("IDEAL", BankTypes, False)
    INTERAC = ("INTERAC_ONLINE", False, False)
    INTERAC_TRANSFER = ("INTERAC_TRANSFER", False, False)
    KLARNA = ("KLARNA_INSTALLMENTS", False, False)
    KLARNA_INVOICE = ("KLARNA_INVOICE", False, False)
    MERCADOLIVRE = ("MERCADOLIVRE", False, False)
    MONETA = ("MONETA", False, False)
    MUCH_BETTER = ("MUCH_BETTER", False, False)
    MULTIBANCO = ("MULTIBANCO", False, False)
    NETELLER = ("NETELLER", False, False)
    OXXO = ("OXXO", False, False)
    PAYPAL = ("PAYPAL", False, False)
    PAYSAFECARD = ("PAYSAFECARD", False, False)
    PNP = ("PNP", False, False)
    SEPA = ("DIRECTDEBIT_SEPA", False, BankDetails)
    SKRILL = ("SKRILL_WALLET", False, False)
    SOFORT = ("SOFORTUEBERWEISUNG", False, False)
    SOLO = ("SOLO", False, False)
    TRUSTLY = ("TRUSTLY_DEPOSIT", False, False)
    TRUSTLYDD = ("TRUSTLY_DIRECT_DEBIT", False, False)
    RAPID_TRANSFER = ("RAPID_TRANSFER", False, False)
    BANK_TRANSFER = ("BANK_TRANSFER", False, False)
    GOOGLE_PAY = ("GOOGLE_PAY", False, BankDetails)
    UPI = ("UPI", False, BankDetails)
    IMPS = ("IMPS", False, BankDetails)
    NET_BANKING = ("NetBanking", False, False)

    def __init__(self, name, info_type, whpp_class):
        self.__value = name
        self.__info_type = info_type
        self.__whpp_class = whpp_class

    @property
    def value(self):
        return self.__value

    @property
    def types(self):
        """Return TypeInfo sub-class
        """

        return self.__info_type

    @property
    def whpp_class(self):
        """Return WHPPInfo sub-class
        """

        return self.__whpp_class


class PaymentMethod(GatewayObject):

    def __init__(self, mode=Modes.HPP, types=None, details=None, payout=False):
        self.mode = mode
        self.types = mode.types(types) if isinstance(types, TypeInfo) else None
        self.addDetails(details)
        self.__payout = payout
        self.__evaluate_signature()

    def __evaluate_signature(self):
        if self.mode == Modes.HPP:
            self.__signature = Fields.ptype_hpp.value
        elif self.details is not None:
            self.__signature = Fields.ptype_whpp.value
        else:
            self.__signature = Fields.ptype_plugin.value
        if self.__payout:
            if self.details is not None:
                self.__signature = Fields.ptype_whpp_payout.value
            else:
                self.__signature = Fields.ptype_payout.value

    def addDetails(self, val):
        without_hpp = isinstance(val, WHPPInfo) or isinstance(val,
                                                              BankDetails)
        self.details = val if without_hpp else None
        return self

    def payout(self):
        self.__payout = True
        self.__evaluate_signature()
        return self

    @property
    def hosted_page(self):
        return self.mode != Modes.CREDITCARD

    def to_dict(self):
        data = {}
        if self.types is not None:
            if isinstance(self.types, CardTypes):
                data["cardType"] = self.types
            if isinstance(self.types, BankTypes):
                data["bankCode"] = self.types
        if self.details is not None:
            data = {"paymentDetail": self.details}
            if isinstance(self.types, CardTypes):
                self.details.card_type = self.types
        return data

    @property
    def signature(self):
        return self.__signature
