from ..common import CommonType


class Events(CommonType):

    all = "*"
    cancel = "cancel"
    capture = "capture"
    chargeback = "chargeback"
    expired = "expired"
    payment = "payment"
    refund = "refund"
    splitPayment = "splitPayment"
    void = "void"
