from .currency import Currency
from gateway.common import GatewayObject, Fields


class Installments(GatewayObject):
    def __init__(self, total_installments, amount, period, types,
                 currency_code, frequency, sequence):
        self.sequence = sequence
        self._period = period
        self._frequency = frequency
        self._total_installments = total_installments
        self._type = types
        self._amount = amount
        self._currency = Currency(currency_code)

    @property
    def sequence(self):
        return self._sequence

    @sequence.setter
    def sequence(self, value):
        if value < 1:
            raise ValueError("Sequence value cannot be less than 1")
        self._sequence = value

    def to_dict(self):
        return {
            Fields.period.value: self._period,
            Fields.frequency.value: self._frequency,
            Fields.total_installments.value: self._total_installments,
            Fields.types.value: self._type,
            Fields.amount.value: self._amount,
            Fields.currency_code.value: self._currency,
            Fields.sequence.value: self._sequence
        }
