from ..common import UIDType, GatewayObject, Fields
from ..utils import merge_dicts


class CustomerID(UIDType):
    pass


class Address(GatewayObject):

    def __init__(self, opts=None, **kwargs):
        config = merge_dicts(opts or {}, kwargs)
        self.firstname = config.get("firstname")
        self.lastname = config.get("lastname")
        self.email = config.get("email")
        self.mobile = config.get("phone_no")
        self.state = config.get("state")
        self.city = config.get("city")
        self.postalcode = config.get("postalcode")
        self.country = config.get("country")
        self.address_line1 = config.get("address_line1")
        self.address_line2 = config.get("address_line2")
        self.__is_shipping = config.get("as_shipping")

    def asShipping(self):
        self.__is_shipping = True

    def to_dict(self):
        def field(key):
            if not self.__is_shipping:
                return key
            key = str(key)
            return 's' + key[0].capitalize() + key[1:]
        data = {
            field(Fields.firstname.value): self.firstname,
            field(Fields.lastname.value): self.lastname,
            field(Fields.emailid.value): self.email,
            field(Fields.mobileno.value): self.mobile,
        }
        data = merge_dicts(
            data,
            {field(Fields.state.value): self.state},
            {field(Fields.city.value): self.city},
            {field(Fields.postalcode.value): self.postalcode},
            {field(Fields.country.value): self.country},
            {field(Fields.addressline1.value): self.address_line1},
            {field(Fields.addressline2.value): self.address_line2},
            allow_empty=False
        )
        return data


class Customer(GatewayObject):
    def __init__(self, opts=None, **kwargs):
        config = merge_dicts(opts or {}, kwargs)
        self._dob = config.get("dob")
        self._ip_address = config.get("ip_address")
        self._billing = config.get("billing")
        self._shipping = config.get("shipping")
        self._channel = config.get("channel")
        if self._shipping:
            self._shipping.asShipping()

    def allow_billship(self):
        return True if self._billing is None else False

    def to_dict(self):
        return merge_dicts({},
                           {
                               Fields.DOB.value: self._dob,
                               Fields.IP_ADDRESS.value: self._ip_address,
                               Fields.BILLING_ADDRESS.value: self._billing,
                               Fields.SHIPPING_ADDRESS.value: self._shipping,
                               Fields.NOTIFICATION_CHANNELS.value:
                               self._channel,
                           },
                           allow_empty=False)


class DynamicDescriptor(GatewayObject):
    def __init__(self, **kwargs):
        super().__init__()
        self._name = "Dynamic Descriptor"
        self.__name = kwargs.get("name")
        self.__email = kwargs.get("email")
        self.__mobile = kwargs.get("mobile")

    def to_dict(self):
        data = merge_dicts(
            {},
            {Fields.name.value: self.__name},
            {Fields.email.value: self.__email},
            {Fields.mobile.value: self.__mobile},
            allow_empty=False
        )
        return data


class AccountHolder(GatewayObject):
    def __init__(self, name, address):
        self._name = "Account Holder Details"
        self.__name = name
        self.__address = address

    def to_dict(self):
        return {
            Fields.name.value: self.__name,
            Fields.address.value: self.__address
        }
