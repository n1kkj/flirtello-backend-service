from pytz import (
    datetime,
    timezone,
    all_timezones,
)
from re import match

from ..common import CommonType


def get_timezone_dict():
    """Get country abbreviated timezone codes"""

    return dict((tzone, tzone) for tzone in filter(
        lambda x: match(r'[A-Z]+', x),
        map(lambda y: datetime.datetime.now(timezone(y)).strftime('%Z'),
            all_timezones)))


TimeZone = CommonType('TimeZone', get_timezone_dict())
