from gateway.common import Fields, GatewayObject, CommonType


class Channel(CommonType):
    """"All Supported notification channel"""
    sms = "sms"
    slack = "slack"
    whatsapp = "whatsapp"
    email = "email"


class NotificationSettings(GatewayObject):

    def __init__(self, channel=None, value=None):
        super().__init__()
        self.__data = []
        if channel:
            self.add_channel(channel, value)

    def add_channel(self, channel, value):
        try:
            self.__data.append({
                Fields.name.value: Channel(channel).value,
                "value": value
            })
        except ValueError:
            pass

    def to_dict(self):
        return self.__data
