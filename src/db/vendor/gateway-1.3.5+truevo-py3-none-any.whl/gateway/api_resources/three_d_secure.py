from ..common import GatewayObject
from ..utils import merge_dicts


class ThreeDSecure(GatewayObject):
    def __init__(self, opts=None, **kwargs):
        config = merge_dicts(opts or {}, kwargs)
        self._challenge_indicator = config.get("challenge_indicator")
        self._challenge_window_size = config.get("challenge_window_size")
        self._external_threeds = config.get("external_threeds")
        self._exemptions = config.get("exemptions")
        self._sdk = config.get("sdk")
        self._device_fingerprint = config.get("device_fingerprint")

    def to_dict(self):
        data = merge_dicts(
            {},
            {"challengeIndicator": self._challenge_indicator},
            {"challengeWindowSize": self._challenge_window_size},
            allow_empty=False,
        )
        if self._external_threeds:
            data["externalThreeds"] = self._external_threeds
        if self._device_fingerprint:
            data["deviceFingerprint"] = self._device_fingerprint
        if self._exemptions:
            data["exemptions"] = self._exemptions
        if self._sdk:
            data["sdk"] = self._sdk
        return data


class ExternalThreeds(GatewayObject):
    def __init__(self, opts=None, **kwargs):
        config = merge_dicts(opts or {}, kwargs)
        self._eci_code = config.get("eci_code")
        self._three_ds_status = config.get("three_ds_status")
        self._acs_txn_id = config.get("acs_txn_id")
        self._ds_txn_id = config.get("ds_txn_id")
        self._three_ds_server_txn_id = config.get("three_ds_server_txn_id")
        self._three_ds_version = config.get("three_ds_version")
        self._authentication_value = config.get("authentication_value")
        self._xid = config.get("xid")

    def to_dict(self):
        return merge_dicts(
            {},
            {"eciCode": self._eci_code},
            {"threedsStatus": self._three_ds_status},
            {"acsTransactionId": self._acs_txn_id},
            {"dsTransactionId": self._ds_txn_id},
            {"threedsServerTransactionId": self._three_ds_server_txn_id},
            {"threedsVersion": self._three_ds_version},
            {"authenticationValue": self._authentication_value},
            {"xid": self._xid},
            allow_empty=False,
        )


class DeviceFingerprint(GatewayObject):
    def __init__(self, opts=None, **kwargs):
        config = merge_dicts(opts or {}, kwargs)
        self.timezone = config.get("timezone")
        self.browser_color_depth = config.get("browser_color_depth")
        self.browser_language = config.get("browser_language")
        self.browser_screen_height = config.get("browser_screen_height")
        self.browser_screen_width = config.get("browser_screen_width")
        self.os = config.get("os")
        self.browser_accept_header = config.get("browser_accept_header")
        self.user_agent = config.get("user_agent")
        self.browser_javascript_enabled = config.get(
            "browser_javascript_enabled")
        self.browser_java_enabled = config.get("browser_java_enabled")
        self.accept_content = config.get("accept_content")
        self.browser_ip = config.get("browser_ip")

    def to_dict(self):
        return merge_dicts(
            {},
            {"timezone": self.timezone},
            {"browserColorDepth": self.browser_color_depth},
            {"browserLanguage": self.browser_language},
            {"browserScreenHeight": self.browser_screen_height},
            {"browserScreenWidth": self.browser_screen_width},
            {"os": self.os},
            {"browserAcceptHeader": self.browser_accept_header},
            {"userAgent": self.user_agent},
            {"browserJavascriptEnabled": self.browser_javascript_enabled},
            {"browserJavaEnabled": self.browser_java_enabled},
            {"acceptContent": self.accept_content},
            {"browserIP": self.browser_ip},
            allow_empty=False
        )


class Exemptions(GatewayObject):
    def __init__(self, opts=None, **kwargs):
        config = merge_dicts(opts or {}, kwargs)
        self._low_value = config.get("low_value")
        self._tra = config.get("tra")
        self._trusted_beneficiary = config.get("trusted_beneficiary")
        self._secure_corporate_payment = config.get(
            "secure_corporate_payment")
        self._delegate_authentication = config.get(
            "delegated_authentication")
        self._recurring_mit_exemption_same_amount = config.get(
            "recurring_mit_exemption_same_amount")
        self._recurring_mit_exemption_other = config.get(
            "recurring_mit_exemption_other")
        self._vmid = config.get("vmid")

    def to_dict(self):
        return merge_dicts(
            {},
            {"lowValue": self._low_value},
            {"tra": self._tra},
            {"trustedBeneficiary": self._trusted_beneficiary},
            {"secureCorporatePayment": self._secure_corporate_payment},
            {"delegatedAuthentication": self._delegate_authentication},
            {"recurringMITExemptionSameAmount":
                self._recurring_mit_exemption_same_amount},
            {"recurringMITExemptionOther":
                self._recurring_mit_exemption_other},
            {"vmid": self._vmid},
            allow_empty=False
        )


class SdkDetails(GatewayObject):
    def __init__(self, opts=None, **kwargs):
        config = merge_dicts(opts or {}, kwargs)
        self._sdk_app_id = config.get("sdk_app_id")
        self._sdk_enc_data = config.get("sdk_enc_data")
        self._sdk_ephem_pub_key = config.get("sdk_ephem_pub_key")
        self._sdk_max_timeout = config.get("sdk_max_timeout")
        self._sdk_reference_number = config.get("sdk_reference_number")
        self._sdk_trans_id = config.get("sdk_trans_id")

    def to_dict(self):
        return merge_dicts(
            {},
            {"sdkAppID": self._sdk_app_id},
            {"sdkEncData": self._sdk_enc_data},
            {"sdkEphemPubKey": self._sdk_ephem_pub_key},
            {"sdkMaxTimeout": self._sdk_max_timeout},
            {"sdkReferenceNumber": self._sdk_reference_number},
            {"sdkTransID": self._sdk_trans_id},
            allow_empty=False
        )
