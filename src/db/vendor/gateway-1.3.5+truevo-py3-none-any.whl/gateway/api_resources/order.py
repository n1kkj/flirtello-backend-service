from ..common import UIDType, GatewayObject, Varien
from ..utils import merge_dicts
from ..common import Fields


class Url(GatewayObject):

    def __init__(self, success, fail, cancel, cart=None,
                 product=None, confirmation_page=False,
                 iframe=False):
        self.success = success
        self.fail = fail
        self.cancel = cancel
        self.cart = cart
        self.product = product
        self.confirmation_page = bool(confirmation_page)
        self._iframe = bool(iframe)

    def iframe(self):
        self._iframe = True
        return self

    def to_dict(self):
        data = {
            "successURL": self.success,
            "cancelURL": self.cancel,
            "failURL": self.fail,
        }
        data = merge_dicts(
            data,
            {"cartURL": self.cart},
            {"productURL": self.product},
            {"showConfirmationPage": self.confirmation_page},
            {"iFrame": self._iframe},
            allow_empty=False,
        )
        return data


class Order(UIDType, GatewayObject):

    def __init__(self, opts=None, **kwargs):
        config = merge_dicts(opts or {}, kwargs)
        self.uid = config.get("uid")
        self.total_value = config.get("total_value")

        self.__details = Varien(config.get("details", {}), attrs={
            "shipping": "shippingCharges",
            "tax": "tax",
            "subtotal": "subtotal",
        })
        self.__discount = Varien(config.get("discount", {}), attrs={
            "coupon_detail": "couponCodeDetails",
            "coupon_code": "couponCode",
            "total": "discountValue",
        })
        self.__items = []

    @property
    def details(self):
        return self.__details

    @property
    def discount(self):
        return self.__discount

    @property
    def items(self):
        return self.__items

    def add_item(self, value):
        item_attrs = {"name": "itemName",
                      "qty": "itemQuantity",
                      "price": "itemPricePerUnit",
                      "sku": "itemId"}
        if not isinstance(value, (dict, list)):
            raise TypeError("value should be 'dict' type or a 'list' of dict")
        if isinstance(value, list):
            for i in value:
                self.__items.append(Varien(i, attrs=item_attrs))
        else:
            self.__items.append(Varien(value, attrs=item_attrs))

    def to_dict(self):
        return merge_dicts(
            {},
            {"orderId": self.uid},
            {"summary":
                merge_dicts(
                    {"totalValue": self.total_value},
                    {"details": self.details},
                    {"discount": self.discount},
                    allow_empty=False
                )},
            {"items": self.items},
            allow_empty=False
        )


class CustomData(GatewayObject):
    def __init__(self, **kwargs):
        self._custom_data1 = kwargs.get("custom_data1")
        self._custom_data2 = kwargs.get("custom_data2")
        self._custom_data3 = kwargs.get("custom_data3")
        self._custom_data4 = kwargs.get("custom_data4")
        self._custom_data5 = kwargs.get("custom_data5")
        self._site = kwargs.get("site")

    def to_dict(self):
        return merge_dicts(
            {},
            {
                Fields.CUSTOM_DATA1.value: self._custom_data1,
                Fields.CUSTOM_DATA2.value: self._custom_data2,
                Fields.CUSTOM_DATA3.value: self._custom_data3,
                Fields.CUSTOM_DATA4.value: self._custom_data4,
                Fields.CUSTOM_DATA5.value: self._custom_data5,
                Fields.SITE.value: self._site,
            },
            allow_empty=False
        )
