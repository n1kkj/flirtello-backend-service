from ..common import Fields, GatewayObject
from ..utils import merge_dicts


class Industry(GatewayObject):
    def __init__(self, **kargs):
        self._travel = kargs.get("travel")
        self._crypto = kargs.get("crypto")

    def to_dict(self):
        return merge_dicts(
            {},
            {
                Fields.TRAVEL.value: self._travel,
                Fields.CRYPTO.value: self._crypto,
            },
            allow_empty=False,
        )


class Travel(GatewayObject):
    def __init__(self, **kargs):
        self._accommodation = kargs.get("accommodation")

    def to_dict(self):
        return merge_dicts(
            {},
            {
                Fields.ACCOMMODATION.value: self._accommodation,
            },
            allow_empty=False,
        )


class Accommodation(GatewayObject):
    def __init__(self, **kargs):
        self._property_name = kargs.get("property_name")
        property_reservation_number = kargs.get("property_reservation_number")
        self._property_reservation_number = property_reservation_number
        self._date_check_in = kargs.get("date_check_in")
        self._date_check_out = kargs.get("date_check_out")
        self._booking_first_name = kargs.get("booking_first_name")
        self._booking_last_name = kargs.get("booking_last_name")

    def to_dict(self):
        return merge_dicts(
            {},
            {
                Fields.PROPERTY_NAME.value: self._property_name,
                Fields.PROPERTY_RESERVATION_NUMBER.value:
                    self._property_reservation_number,
                Fields.DATE_CHECK_IN.value: self._date_check_in,
                Fields.DATE_CHECK_OUT.value: self._date_check_out,
                Fields.BOOKING_FIRST_NAME.value: self._booking_first_name,
                Fields.BOOKING_LAST_NAME.value: self._booking_last_name,
            },
            allow_empty=False,
        )


class Crypto(GatewayObject):
    def __init__(self, **kargs):
        self._wallet_address = kargs.get("wallet_address")
        self._public_address_indicator = kargs.get("public_address_indicator")
        self._wallet_sanction_checked = kargs.get("wallet_sanction_checked")
        self._is_wallet_sanctioned = kargs.get("is_wallet_sanctioned")
        self._crypto_currency = kargs.get("crypto_currency")

    def to_dict(self):
        return merge_dicts(
            {},
            {
                Fields.WALLET_ADDRESS.value: self._wallet_address,
                Fields.PUBLIC_ADDRESS_INDICATOR.value:
                    self._public_address_indicator,
                Fields.WALLET_SANCTION_CHECKED.value:
                    self._wallet_sanction_checked,
                Fields.IS_WALLET_SANCTIONED.value: self._is_wallet_sanctioned,
                Fields.CRYPTO_CURRENCY.value: self._crypto_currency,
            },
            allow_empty=False,
        )
