from ..common import GatewayObject, Fields, ConstantType
from ..utils import merge_dicts


class Source(ConstantType):
    CIT = "CIT"
    MIT = "MIT"


class RecurringType(ConstantType):
    UNSCHEDULED = "UNSCHEDULED"
    RECURRING = "RECURRING"


class Reason(ConstantType):
    REAUTHORIZATION = "REAUTHORIZATION"
    RESUBMISSION = "RESUBMISSION"
    INSTALLMENT = "INSTALLMENT"
    DELAYED_CHARGES = "DELAYED_CHARGES"
    NOT_SHOW = "NOT_SHOW"


class Recurring(GatewayObject):
    def __init__(self, **kwargs):
        self._source = kwargs.get("source")
        self._recurring_type = kwargs.get("recurring_type")
        self._reason = kwargs.get("reason")

    def to_dict(self):
        return merge_dicts({},
                           {
                               Fields.SOURCE.value: self._source,
                               Fields.RECURRING_TYPE.value:
                               self._recurring_type,
                               Fields.REASON.value: self._reason,
                           },
                           allow_empty=False)
