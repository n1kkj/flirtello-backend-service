class GatewayError(Exception):
    """Base exception"""
    pass


class ConfigurationError(GatewayError):
    pass


class ValidationError(GatewayError):
    pass
