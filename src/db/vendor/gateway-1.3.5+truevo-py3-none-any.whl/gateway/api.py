import requests as _requests
from .common import Endpoints as _Endpoints
from .crypt import Crypt as _Crypt
from .exceptions import ConfigurationError, GatewayError
from .utils import Validator
from .log import Log
import os
import json


class Api:

    def __init__(self, key, token, cert):
        self.key = key
        self.token = token
        self.cert = cert
        self.__endpoint = _Endpoints.test.value
        self.__crypt = _Crypt(self.token, self.cert)

    def decrypt(self, data):
        return self.__crypt.decrypt(data)

    def decrypt_and_convert(self, data):
        return self.__crypt.decrypt_and_convert(data)

    def live(self):
        self.__endpoint = _Endpoints.live.value
        return self

    def get_lib_path(self):
        lib_path = os.path.join(os.path.split(__file__)[0],
                                "js/iframe-sdk.js")
        return lib_path

    @property
    def endpoint(self):
        return self.__endpoint

    @staticmethod
    def get():
        global __gateway_api__
        try:
            if True in map(Validator.empty, (
                    __gateway_api__.key,
                    __gateway_api__.token,
                    __gateway_api__.endpoint,
                    __gateway_api__.cert,
            )):
                raise ConfigurationError('Empty API credentials')
        except NameError:
            raise ConfigurationError('SDK not initialized')
        return __gateway_api__

    def __request(
            self,
            data,
            method=None,
            headers=None,
            route=None,
            lang=None):
        """Perform HTTP request, data can be string or bytes"""
        payload = self._prepare_payload(data, lang)
        url = self.endpoint + (route or "")
        Log.DEBUG("Sending %s request to %s. Header: %s. Data: %s",
                  method, url, headers, payload)
        response = _requests.request(
            method=method,
            url=url,
            data=payload,
            headers=headers
        )
        Log.DEBUG("Response received: %s. Content: %s",
                  response, response.content)
        return response

    def _prepare_payload(self, data, lang):
        if Validator.empty(data):
            raise GatewayError('Request data cannot be empty')
        if json.loads(data.decode("utf-8")) is None:
            return
        try:
            data = data.encode()
        except AttributeError:
            pass
        return {
            "payLoad": self.__crypt.encrypt(data).decode(),
            "apiKey": self.key,
            "lang": lang,
        }

    def send(self, req):
        """Send request to gateway"""
        info_dict = req.get_request_dict()
        headers = {}
        try:
            headers = req.get_headers_dict()
        except AttributeError:
            pass
        return self.__request(
            data=info_dict['data'],
            method=info_dict['method'],
            headers=headers,
            route=info_dict['route'],
            lang=info_dict['lang'])

    @endpoint.setter
    def endpoint(self, value):
        self.__endpoint = value


def configure(key, token, cert):
    global __gateway_api__
    __gateway_api__ = Api(key, token, cert)
    Log.update_api_key(key)
    return __gateway_api__
