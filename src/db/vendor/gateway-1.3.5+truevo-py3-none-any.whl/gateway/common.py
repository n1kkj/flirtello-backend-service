from enum import Enum as _Enum
from json import JSONEncoder as _Encoder

from .utils import Validator


class CommonType(_Enum):
    pass


class ConstantType(CommonType):
    pass


class UIDType:

    def __init__(self, uid):
        self.uid = uid

    @property
    def uid(self):
        return self.__uid

    @uid.setter
    def uid(self, value):
        self.__uid = value.uid if isinstance(value, self.__class__) else value

    def __eq__(self, o):
        uid = str(self)
        if not o and Validator.empty(uid):
            return True
        return uid == str(o)

    def __str__(self):
        return str(self.uid) if self.uid else ""

    def __repr__(self):
        return "<[%s ID:%s] object at %s>" % (
            type(self).__name__, self.uid, hex(id(self)))


class RecrEncoder(_Encoder):
    """Utilize GatewayObject to build json recursively
    """

    def default(self, o):
        if isinstance(o, GatewayObject):
            return o.to_dict()
        if isinstance(o, UIDType):
            return str(o)
        if isinstance(o, CommonType):
            return o.value
        return super(RecrEncoder, self).default(o)


class GatewayObject:

    def to_dict(self):
        """Return object's as a dictionary
        """
        pass

    def encode(self):
        """Recursively encode object
        """
        return RecrEncoder().encode(self).encode()

    def __len__(self):
        return len(self.to_dict())


class Varien(GatewayObject):
    _attrs = {}

    def __call__(self, *values):
        if isinstance(values[0], dict):
            for key, val in values[0].items():
                setattr(self, key, val)
        elif isinstance(values[0], str) and len(values) > 1:
            setattr(self, values[0], values[1])

    def __getattr__(self, name):
        if name not in self._attrs.keys():
            raise AttributeError("Available %s, got '%s'"
                                 % (list(self._attrs), name))
        return self.__dict__.get(name, None)

    def __setattr__(self, name, value):
        if name == "_attrs":
            self.__dict__[name] = value
        elif name in self._attrs.keys():
            self.__dict__.setdefault('data', {})[self._attrs[name]] = value
            self.__dict__[name] = value
        else:
            raise AttributeError("Available %s, got '%s'"
                                 % (list(self._attrs), name))

    def __init__(self, opts=None, attrs=None):
        if opts is None:
            opts = {}
        if attrs:
            self._attrs = attrs
        for key, value in opts.items():
            setattr(self, key, value)

    def to_dict(self):
        return self.__dict__.setdefault('data', {})


class ApiType:
    TRANSACTION_STATUS = "transactionStatus"
    DEACTIVATE_PLAN = "deactivatePlan"
    GET_PLAN_DETAILS = "getPlanDetails"
    UPDATE_PLAN = "updatePlan"
    CREATE_PLAN = "createPlan"
    SCHEDULE_UPDATE_SUBSCRIPTION = "scheduleUpdateSubscription"
    GET_SUBSCRIPTION_DETAILS = "getSubscriptionDetails"
    DEACTIVATE_SUBSCRIPTION = "deactivateSubscription"
    UPDATE_SUBSCRIPTION = "updateSubscription"
    CREATE_SUBSCRIPTION = "createSubscription"
    REFUND_DETAILS = "refundDetails"
    GET_LINK_DETAILS = "getLinkDetails"
    CLIENT_AUTH = "clientAuth"
    DEACTIVATE_LINK = "deactivateLink"
    VOID_PAYMENT = "voidPayment"
    CAPTURE_PAYMENT = "capturePayment"
    UPDATE_LINK = "updateLink"
    REFUND = "refund"
    PROCESS_PAYOUT = "processPayout"


class Route:
    WIRE_TRANSFER = "/wire-transfer"
    PLANS = "/plans"
    SUBSCRIPTIONS = "/subscriptions"
    PAYMENT_LINK = '/paymentLink'
    PARTNER_API = "/partnerAPI"
    PAYOUT = "/payout"


class Fields(ConstantType):
    transaction = "transaction"
    customer = "customer"
    quantity = "quantity"
    start_date = "startDate"
    plan_id = "planId"
    merchant = "merchant"
    merchant_id = "merchantID"
    currency_code = "currencyCode"
    txn_ref = "txnReference"
    show_custom_data = "showCustomData"
    customer_id = "customerID"
    firstname = 'firstName'
    lastname = 'lastName'
    emailid = 'emailId'
    mobileno = 'mobileNo'
    addressline1 = 'addressLine1'
    addressline2 = 'addressLine2'
    city = 'city'
    state = 'state'
    country = 'country'
    region = 'state'
    postalcode = 'zip'
    token_id = "tokenID"
    token = "token"
    acquirer = "acquirer"
    acquirer_token = "acquirerToken"
    all_cards = "showAllCards"
    allow3d = "allow3D"
    pagetag = "pageTag"
    report_type = "reportType"
    report_from_count = "fromCount"
    report_limit = "limit"
    report_from_date = "fromDate"
    report_to_date = "toDate"
    report_filters = "filters"
    sort_order = "sortOrder"
    sort_column = "sortColumn"
    locale = "locale"
    capture_txn = "capture"
    void_txn = "void"
    filter_field = "fieldName"
    filter_value = "fieldValue"
    refund = "refund"
    refund_amount = "refundAmount"
    refund_invoice = "refundInvoiceNo"
    refund_status = "refundStatus"
    comments = "comments"
    card = "card"
    card_token = "tokenID"
    card_number = "cardNumber"
    card_year = "expYear"
    card_month = "expMonth"
    card_name = "nameOnCard"
    card_cvv = "cvv"
    card_save = "saveDetails"
    card_type = "cardType"
    card_bin = "bin"
    card_last4 = "last4"
    ptype_hpp = "withHPP"
    ptype_whpp = "withoutHPP"
    ptype_plugin = "pluginCheckout"
    ptype_payout = "payout"
    ptype_whpp_payout = "withoutHppPayout"
    name = "name"
    email = "email"
    mobile = "mobile"
    period = "period"
    frequency = "frequency"
    total_installments = "totalInstallments"
    types = "type"
    sequence = "sequence"
    amount = "amount"
    description = "description"
    code = "code"
    carry_forward_amount = "carryForwardAmount"
    payment_failure_threshold = "paymentFailureThreshold"
    automatic_debit = "automaticDebit"
    total_cycles = "totalCycles"
    expire_in = "expireIn"
    enc_card_number = "encCardNumber"
    enc_algorithm = "encAlgorithm"
    key_sequence_number = "keySequenceNumber"
    address = "address"
    bic = "bic"
    account_number = "accountNumber"
    iban = "iban"
    sort_code = "sortCode"
    default = "default"
    bank = "bank"
    account_holder = "accountHolder"
    european = "isEEA"
    subscription_id = "subscriptionId"
    payout = "payout"
    executionDate = "executionDate"
    threedSecure = "3DSecure"
    payment_token = "paymentToken"
    holder = "holder"

    # Custom Data
    CUSTOM_DATA = "customData"
    CUSTOM_DATA1 = "customData1"
    CUSTOM_DATA2 = "customData2"
    CUSTOM_DATA3 = "customData3"
    CUSTOM_DATA4 = "customData4"
    CUSTOM_DATA5 = "customData5"
    SITE = "site"

    # Recurring
    SOURCE = "source"
    RECURRING_TYPE = "recurringType"
    REASON = "reason"
    RECURRING = "recurring"

    # Customer
    DOB = "dob"
    IP_ADDRESS = "ipAddress"
    NOTIFICATION_CHANNELS = "notificationChannels"
    BILLING_ADDRESS = "billingAddress"
    SHIPPING_ADDRESS = "shippingAddress"

    # Industry
    INDUSTRY = "industry"
    TRAVEL = "travel"
    ACCOMMODATION = "accommodation"
    PROPERTY_NAME = "propertyName"
    PROPERTY_RESERVATION_NUMBER = "propertyReservationNumber"
    DATE_CHECK_IN = "dateCheckIn"
    DATE_CHECK_OUT = "dateCheckOut"
    BOOKING_FIRST_NAME = "bookingFirstName"
    BOOKING_LAST_NAME = "bookingLastName"
    CRYPTO = "crypto"
    WALLET_ADDRESS = "walletAddress"
    PUBLIC_ADDRESS_INDICATOR = "publicAddressIndicator"
    WALLET_SANCTION_CHECKED = "walletSanctionChecked"
    IS_WALLET_SANCTIONED = "isWalletSanctioned"
    CRYPTO_CURRENCY = "cryptoCurrency"

    MID_TAG = "midTag"
    FALLBACK_MID_TAG = "fallbackMidTag"


class Endpoints(ConstantType):
    live = "https://api.my.truevo.com"
    test = "https://stagapi.my.truevo.com"


class Separator:
    FORWARD_SLASH = "/"
