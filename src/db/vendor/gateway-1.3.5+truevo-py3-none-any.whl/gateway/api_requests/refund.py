from ..api_resources import Txn
from ..common import Fields, Route, ApiType
from ..request import AuthTokenRequest
from ..log import Log


class Refund(AuthTokenRequest):

    def __init__(self, txn, amount, invoice_no=None, comment=None, api=None,
                 dynamic_descriptor=False):
        Log.DEBUG("Initiating refund request")
        super().__init__(api)
        self._name = "Refund Transaction"
        self._signature = ApiType.REFUND
        self._route = Route.PARTNER_API
        self._txn_id = txn if isinstance(txn, Txn) else Txn(txn)
        self.__amount = amount
        self.__invoice_no = invoice_no
        self.__comment = comment
        self.__dynamic_descriptor = dynamic_descriptor
        self.set_api(api)

    def to_dict(self):
        data = {
            Fields.merchant_id.value: self.api.key,
            Fields.refund.value: {
                Fields.refund_amount.value: self.__amount,
                Fields.txn_ref.value: str(self.txn_id),
            }
        }
        if self.__comment:
            data[Fields.refund.value][Fields.comments.value] = self.__comment
        if self.__invoice_no:
            data[Fields.refund.value][
                Fields.refund_invoice.value] = self.__invoice_no
        if self.__dynamic_descriptor:
            data['dynamicDescriptor'] = self.__dynamic_descriptor
        return data


class RefundStatus(AuthTokenRequest):

    def __init__(self, txn, api=None):
        Log.DEBUG("Initiating refund status request")
        super().__init__(api)
        self._name = "Refund Status"
        self._signature = ApiType.REFUND_DETAILS
        self._route = Route.PARTNER_API
        self._txn_id = txn if isinstance(txn, Txn) else Txn(txn)
        self.set_api(api)

    def to_dict(self):
        return {
            Fields.merchant_id.value: self.api.key,
            Fields.refund_status.value: {
                Fields.txn_ref.value: str(self.txn_id),
            }
        }
