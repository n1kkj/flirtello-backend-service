import requests as _requests
from ..api_resources import (
    Txn,
    PaymentMethod,
    Modes,
    CustomerID,
)
from ..common import Fields, RecrEncoder, Route, ApiType
from ..request import AuthTokenRequest
from ..utils import merge_dicts
from ..log import Log
from ..exceptions import GatewayError


class Payment(AuthTokenRequest):

    def __init__(self, txn, customer_id, payment, url, opts=None, **kwargs):
        if 'initial_log' not in kwargs.keys():
            Log.DEBUG("Initiating payment request")
        super().__init__()
        self._route = Route.PARTNER_API
        self._name = "Create Transaction"
        self._signature = ApiType.CLIENT_AUTH
        config = merge_dicts(opts or {}, kwargs)
        self._txn_id = txn if isinstance(txn, Txn) else Txn(None)
        self.__customer_id = customer_id if isinstance(
            customer_id, CustomerID) else CustomerID(customer_id)
        self.__payment = payment if isinstance(
            payment, PaymentMethod) else PaymentMethod()
        self.set_api(config.get("api"))
        self.order = config.get("order")
        self.assync = config.get("sync", False)
        self._allow3d = config.get("allow3d")
        self._pagetag = config.get("pagetag")
        self._allow_billship = config.get("allowBillShip", False)
        self.__dynamic_descriptor = config.get("dynamic_descriptor")
        self.__three_d_secure = config.get("three_d_secure")
        self._subscription_id = config.get("subscription_id")
        self._execution_date = config.get("execution_date")
        self._is_app = config.get("is_app", False)
        self._payout = config.get("payout", False)
        self.__url = url
        self._payment_link = False
        self._custom_data = config.get("custom_data")
        self._recurring = config.get("recurring")
        self._customer = config.get("customer")
        self._industry = config.get("industry")
        self._mid_tag = config.get("mid_tag")
        self._fallback_mid_tag = config.get("fallback_mid_tag")
        self._plan = config.get("plan")
        self._description = config.get("description")
        self._total_cycles = config.get("total_cycles")
        self._quantity = config.get("quantity")
        self._expire_in = config.get("expire_in")
        self._automatic_debit = config.get("automatic_debit")

    @property
    def payment(self):
        return self.__payment

    @property
    def url(self):
        return self.__url

    @property
    def currency(self):
        return self._txn_id.currency

    @property
    def amount(self):
        return self._txn_id.amount

    def sync(self):
        self.assync = True
        return self

    def allow3d(self):
        self._allow3d = True
        return self

    def disallow3d(self):
        self._allow3d = False
        return self

    def set_page_tag(self, tag):
        self._pagetag = tag
        return self

    def generate_payment_link(self):
        self._route = "/paymentLink/" + self.api.key
        self._signature = "generateLink"
        self._payment_link = True
        if self._customer:
            self._allow_billship = self._customer.allow_billship()
        else:
            self._allow_billship = True
        return self

    def get_post_data(self):
        class PostPayment(AuthTokenRequest):
            def __init__(self, obj):
                super().__init__()
                self._name = "Post clientAuth"
                self.set_api(obj.api)
                self._txn_id = obj.txn_id
                self._signature = obj.payment.signature
                self._sync = obj.assync
                response_dict = dict(obj.response.json())
                if 'payLoad' not in response_dict.keys():
                    raise GatewayError('No Payload in clientAuth response')
                self.url = self.api.decrypt(response_dict['payLoad'])

            def to_dict(self):
                return merge_dicts(
                    self.get_headers_dict(), {
                        Fields.merchant_id.value: self.api.key,
                        "gatewayReference": self.url.split('/')[3],
                        "sync": self._sync,
                    })

            def process(self):
                data = RecrEncoder().encode(
                    self.api._prepare_payload(self.encode(), self.lang)
                ).encode()
                return {"action": self.url, "value": {"data": data}}

        data = PostPayment(self).process()
        if not self.assync:
            Log.DEBUG("Post data: %s", data)
            return data
        Log.DEBUG("Sending post request to %s. Data: %s",
                  data['action'], data['value'])
        response = _requests.post(data['action'], data=data['value'])
        Log.DEBUG("Response received: %s. Content: %s",
                  response, response.content)
        return response

    def send(self):
        super().send()
        if self.assync:
            self.response = self.get_post_data()

        class Response(_requests.Response):

            def __init__(self, req_response, payment):
                self.payment = payment
                for k, v in req_response.__dict__.items():
                    self.__dict__[k] = v

            def iframe(self, wrapper_class=""):
                lib = open(self.payment.api.get_lib_path(), 'r')
                post = self.payment.get_post_data()
                return ("<script>{0} __gatewayIFrame.initPaymentIFrame('{1}',"
                        "'{2}', '{3}');</script>").format(
                    lib.read(),
                    post['value']['data'].decode(),
                    post['action'],
                    wrapper_class)

        self.response = Response(self.response, self)
        return self.response

    def to_dict(self):
        data = {
            "lang": self.lang,
            "merchant": {
                Fields.merchant_id.value: self.api.key,
                Fields.customer_id.value: self.__customer_id,
            },
            "transaction": {
                "txnAmount": self.amount,
                "async": not self.assync,
                Fields.currency_code.value: self.currency,
                Fields.txn_ref.value: self.txn_id,
                "isApp": self._is_app,
                Fields.payout.value: self._payout
            },
            "url": self.url
        }
        if self.payment.mode is not Modes.HPP:
            data['transaction']['paymentMode'] = self.payment.mode
        if self.order:
            data.update(self.order.to_dict())
        if self.__three_d_secure:
            data["transaction"][Fields.threedSecure.value] = \
                self.__three_d_secure
        if self._allow3d is not None:
            data["transaction"][Fields.allow3d.value] = self._allow3d
        if self._execution_date is not None:
            data["transaction"][Fields.executionDate.value] = \
                self._execution_date
        if self._subscription_id is not None:
            data["transaction"][
                Fields.subscription_id.value] = self._subscription_id
        if self._pagetag is not None:
            data["transaction"][Fields.pagetag.value] = self._pagetag
        data['transaction'].update(self.payment.to_dict())
        if self._payment_link:
            data['transaction']['allowBillShip'] = self._allow_billship
            data['transaction']['paymentLink'] = self._payment_link
        if self._customer:
            data[Fields.customer.value] = self._customer
        if self.__dynamic_descriptor:
            data['dynamicDescriptor'] = self.__dynamic_descriptor
        if self._recurring:
            data[Fields.RECURRING.value] = self._recurring
        if self._custom_data:
            data[Fields.CUSTOM_DATA.value] = self._custom_data
        if self._industry:
            data[Fields.INDUSTRY.value] = self._industry
        if self._mid_tag:
            data['transaction'][Fields.MID_TAG.value] = self._mid_tag
        if self._fallback_mid_tag:
            fallback = self._fallback_mid_tag
            data['transaction'][Fields.FALLBACK_MID_TAG.value] = fallback
        if self._plan:
            data['plan'] = self._plan
        if self._description:
            data[Fields.description.value] = self._description
        if self._total_cycles:
            data[Fields.total_cycles.value] = self._total_cycles
        if self._quantity:
            data[Fields.quantity.value] = self._quantity
        if self._expire_in:
            data[Fields.expire_in.value] = self._expire_in
        if self._automatic_debit:
            data[Fields.automatic_debit.value] = self._automatic_debit
        return data
