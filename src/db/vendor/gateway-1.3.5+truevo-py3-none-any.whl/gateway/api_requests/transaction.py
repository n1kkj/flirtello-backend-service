from datetime import datetime as _datetime

from ..api_resources import Txn, TimeZone
from ..common import (
    Fields as _Fields,
    ConstantType as _ConstantType, Route, ApiType,
)
from ..request import (
    AuthTokenRequest as _AuthTokenRequest,
    Request,
)
from ..utils import Validator, ymd_to_datetime
from ..log import Log


class TransactionStatus(_AuthTokenRequest):
    def __init__(self, txn, api=None):
        Log.DEBUG("Initiating transaction status request")
        super().__init__(api)
        self._name = "Transaction Status"
        self._signature = ApiType.TRANSACTION_STATUS
        self._route = Route.PARTNER_API
        self._txn_id = Txn(txn)
        self.set_api(api)

    def to_dict(self):
        return {
            _Fields.merchant_id.value: self.api.key,
            _Fields.txn_ref.value: self.txn_id,
            _Fields.show_custom_data.value: True,
        }


class Report(Request):
    class ReportType(_ConstantType):
        transactionReport = "transactionReport"
        refundReport = "refundReport"
        chargebackReport = "chargebackReport"
        customerPayoutsReport = "customerPayoutsReport"

    class SortOrder(_ConstantType):
        asc = "asc"
        desc = "desc"

    class Column(_ConstantType):
        transactionDate = "transactionDate"
        txnReference = "txnReference"
        paymentMode = "paymentMode"
        status = "status"
        currencyCode = "currencyCode"
        cardHolderName = "cardHolderName"
        ipAddress = "ipAddress"

    def __init__(self, report=ReportType.transactionReport,
                 column=Column.transactionDate, order=SortOrder.asc,
                 timezone=TimeZone.GMT, from_date=_datetime.now(),
                 to_date=_datetime.now(), api=None):
        Log.DEBUG("Initiating report request")
        super().__init__(api)
        self._name = "Transaction Report"
        self._route = Route.PARTNER_API
        self.__report = self.ReportType(report)
        self.__column = self.Column(column)
        self.__order = self.SortOrder(order)
        self.__timezone = TimeZone(timezone)
        self.__fdate, self.__tdate = map(ymd_to_datetime,
                                         [from_date, to_date])
        self.set_api(api)
        self.clear_filter()
        self.paginate(0, 0)

    def filter(self, column, value):
        try:
            value = value.value
        except AttributeError:
            pass
        self.__filters[str(self.Column(column).value)] = value

    def clear_filter(self):
        self.__filters = {}

    def paginate(self, page, items=10):
        page, self.__limit = map(lambda x: abs(int(x)), [page, items])
        self.__fcount = page * self.__limit

    def to_dict(self):
        payload = {
            _Fields.merchant.value: {
                _Fields.merchant_id.value: self.api.key,
            },
            _Fields.report_type.value: self.__report,
            _Fields.report_from_count.value: self.__fcount,
            _Fields.report_limit.value: self.__limit,
            _Fields.sort_order.value: self.__order,
            _Fields.sort_column.value: self.__column,
            _Fields.locale.value: self.__timezone,
            _Fields.report_from_date.value: self.__fdate.strftime("%Y-%m-%d"),
            _Fields.report_to_date.value: self.__tdate.strftime("%Y-%m-%d"),
        }
        if not Validator.empty(self.__filters):
            payload.update({
                _Fields.report_filters.value: (lambda: [{
                    _Fields.filter_field.value: f,
                    _Fields.filter_value.value: v,
                } for i, (f, v) in enumerate(self.__filters.items())])()
            })
        return payload
