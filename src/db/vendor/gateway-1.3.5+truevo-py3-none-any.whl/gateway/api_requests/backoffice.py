from ..api_resources import Currency, Txn
from ..common import Fields, ApiType, Route
from ..request import AuthTokenRequest, Request
from ..log import Log


class Configuration(Request):

    def __init__(self, currency, api=None):
        Log.DEBUG("Initiating configuration request")
        super().__init__(api)
        self._name = "Merchant Configuration"
        self._route = Route.PARTNER_API
        self.__currency = Currency(currency)
        self.set_api(api)

    def to_dict(self):
        return {
            Fields.merchant_id.value: self.api.key,
            Fields.currency_code.value: self.__currency,
        }


class Capture(AuthTokenRequest):

    def __init__(self, txn, currency, api=None, dynamic_descriptor=None):
        Log.DEBUG("Initiating capture request")
        super().__init__(api)
        self._name = "Capture Transaction"
        self._signature = ApiType.CAPTURE_PAYMENT
        self._route = Route.PARTNER_API
        self._txn_id = Txn(txn)
        self.__currency = Currency(currency)
        self.__dynamic_descriptor = dynamic_descriptor
        self.set_api(api)

    def to_dict(self):
        data = {
            Fields.merchant_id.value: self.api.key,
            Fields.capture_txn.value: {
                Fields.txn_ref.value: self.txn_id,
                Fields.currency_code.value: self.__currency,
            }
        }
        if self.__dynamic_descriptor:
            data['dynamicDescriptor'] = self.__dynamic_descriptor
        return data


class Void(AuthTokenRequest):

    def __init__(self, txn, api=None, dynamic_descriptor=None):
        Log.DEBUG("Initiating void request")
        super().__init__(api)
        self._name = "Void Transaction"
        self._signature = ApiType.VOID_PAYMENT
        self._route = Route.PARTNER_API
        self._txn_id = Txn(txn)
        self.__dynamic_descriptor = dynamic_descriptor
        self.set_api(api)

    def to_dict(self):
        data = {
            Fields.merchant_id.value: self.api.key,
            Fields.void_txn.value: {
                Fields.txn_ref.value: self.txn_id,
            }
        }
        if self.__dynamic_descriptor:
            data['dynamicDescriptor'] = self.__dynamic_descriptor
        return data
