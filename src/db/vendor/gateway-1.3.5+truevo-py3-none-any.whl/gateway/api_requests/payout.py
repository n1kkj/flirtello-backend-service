from ..api_requests import Payment
from ..request import AuthTokenRequest, HttpMethod
from ..common import Route, ApiType, Separator
from ..log import Log


class Payout(Payment):

    def __init__(self, txn, customer_id, payment, url, email, opts=None,
                 **kwargs):
        Log.DEBUG("Initiating payout request")
        kwargs['initial_log'] = None
        super().__init__(txn, customer_id, payment, url, opts, **kwargs)
        self.__email = email

    def to_dict(self):
        self.payment.payout()
        data = super().to_dict()
        data["transaction"].update({
            "payout": "true",
            "hostedPage": self.payment.hosted_page,
            "customerEmail": self.__email,
            "async": not self.assync,
        })
        return data


class ApprovePayout(AuthTokenRequest):
    def __init__(self, txn_id, api=None):
        Log.DEBUG("Initiating approve payout request")
        super().__init__(api)
        self._txn_id = txn_id
        self._name = "Approve Payout"
        self._signature = ApiType.PROCESS_PAYOUT
        self._method = HttpMethod.put.value
        self._route = Separator.FORWARD_SLASH + self.api.key + \
            Route.PAYOUT + Separator.FORWARD_SLASH + txn_id


class DeclinePayout(AuthTokenRequest):
    def __init__(self, txn_id, api=None):
        Log.DEBUG("Initiating decline payout request")
        super().__init__(api)
        self._txn_id = txn_id
        self._name = "Decline Payout"
        self._signature = ApiType.PROCESS_PAYOUT
        self._method = HttpMethod.delete.value
        self._route = Separator.FORWARD_SLASH + self.api.key + \
            Route.PAYOUT + Separator.FORWARD_SLASH + txn_id
