from gateway.request import HttpMethod

from gateway import Txn
from ..common import Fields, Route, ApiType, Separator

from ..request import AuthTokenRequest as _AuthTokenRequest
from ..utils import merge_dicts
from ..log import Log


class _PaymentLink(_AuthTokenRequest):
    def __init__(self, link_id=None, api=None):
        super().__init__(api)
        self.link_id = link_id
        self._txn_id = Txn(link_id)
        self.set_api(api)
        self._route = \
            Route.PAYMENT_LINK + Separator.FORWARD_SLASH + \
            self.api.key + Separator.FORWARD_SLASH + \
            self.link_id


class GetPaymentLinkDetails(_PaymentLink):
    def __init__(self, link_id, api=None):
        Log.DEBUG("Initiating get payment link details request")
        super().__init__(link_id=link_id, api=api)
        self._name = "Get Payment Link Details"
        self._signature = ApiType.GET_LINK_DETAILS
        self._method = HttpMethod.get.value


class DeactivatePaymentLink(_PaymentLink):
    def __init__(self, link_id, api=None):
        _PaymentLink.__init__(self, link_id=link_id, api=api)
        Log.DEBUG("Initiating deactivate payment link request")
        self._name = "Deactivate Payment Link Details"
        self._signature = ApiType.DEACTIVATE_LINK
        self._method = HttpMethod.delete.value


class UpdatePaymentLink(_PaymentLink):
    def __init__(self, link_id, api=None, opts=None, **kwargs):
        Log.DEBUG("Initiating update payment link request")
        super().__init__(link_id, api)
        self._name = "Update Payment Link Details"
        self._signature = ApiType.UPDATE_LINK
        self._method = HttpMethod.put.value
        self.link_id = link_id
        config = merge_dicts(opts or {}, kwargs)
        self.url = config.get('url')
        self._allow3d = config.get('allow3D')
        self._amount = config.get("amount")
        self._currency = config.get("currency")
        self._allowBillShip = config.get("allowBillShip")
        self._dynamic_descriptor = config.get("dynamic_descriptor")
        self._customer = config.get("customer")
        self._custom_data = config.get("custom_data")

    def to_dict(self):
        data = {
            Fields.merchant_id.value: self.api.key,
        }
        if self._currency or self._amount or \
                self._allow3d or self._allowBillShip:
            data['transaction'] = merge_dicts(
                {},
                {"txnAmount": self._amount},
                {"allowBillShip": self._allowBillShip},
                {Fields.allow3d.value: self._allow3d},
                {Fields.currency_code.value: self._currency},
                allow_empty=False,
            )

        if self.url is not None:
            data['url'] = self.url
        if self._dynamic_descriptor:
            data['dynamicDescriptor'] = self._dynamic_descriptor
        if self._customer:
            data[Fields.customer.value] = self._customer
        if self._custom_data:
            data[Fields.CUSTOM_DATA.value] = self._custom_data
        return data
