from gateway import Txn
from gateway.api_resources.installments import Installments
from gateway.common import Fields, Route, ApiType, Separator
from gateway.request import AuthTokenRequest, HttpMethod
from gateway.utils import merge_dicts
from gateway.log import Log


class _SubscriptionPlan(AuthTokenRequest):
    def __init__(self, plan_id=None, api=None):
        super().__init__(api)
        self._txn_id = Txn(plan_id)
        self._route = Separator.FORWARD_SLASH + self.api.key + \
            Route.PLANS
        if plan_id:
            self._route = self._route + \
                Separator.FORWARD_SLASH + plan_id


class CreatePlan(_SubscriptionPlan):
    def __init__(self, name, code, installements, description=None,
                 carry_forward_amount=None,
                 payment_failure_threshold=None, api=None,
                 plan_id=None, initial_log=True):
        if initial_log:
            Log.DEBUG("Initiating create plan request")
        super().__init__(api=api, plan_id=plan_id)
        self._signature = ApiType.CREATE_PLAN
        self._name = "Create Plan"

        self.__name = name
        self._installments = [
            installements
        ] if isinstance(installements, Installments) else []
        self._description = description
        self._code = code
        self._carry_forward_amount = bool(carry_forward_amount)
        self._payment_failure_threshold = payment_failure_threshold

    def add_installment(self, installment):
        if isinstance(installment, Installments):
            self._installments.append(installment)
        else:
            raise ValueError

    def to_dict(self):
        data = {
            Fields.name.value: self.__name,
            "installments": self._installments
        }
        data = merge_dicts(
            data,
            {Fields.description.value: self._description},
            {Fields.code.value: self._code},
            {Fields.carry_forward_amount.value: self._carry_forward_amount},
            {
                Fields.payment_failure_threshold.value:
                    self._payment_failure_threshold},
            allow_empty=False
        )
        return data


class UpdateSubscriptionPlan(CreatePlan):
    def __init__(self, plan_id, name, installements, description=None,
                 code=None, carry_forward_amount=None,
                 payment_failure_threshold=None, api=None):
        Log.DEBUG("Initiating update subscription plan request")
        super().__init__(name, code, installements, description,
                         carry_forward_amount,
                         payment_failure_threshold, api, plan_id=plan_id,
                         initial_log=False)
        self._signature = ApiType.UPDATE_PLAN
        self.plan_id = plan_id
        self._name = "Update Plan"
        self._method = HttpMethod.put.value


class GetSubscriptionPlanDetails(_SubscriptionPlan):
    def __init__(self, plan_id, api=None):
        Log.DEBUG("Initiating get subscription plan details request")
        super().__init__(plan_id, api)
        self._name = "Get Plan Details"
        self._signature = ApiType.GET_PLAN_DETAILS
        self._method = HttpMethod.get.value


class DeactivateSubscriptionPlan(_SubscriptionPlan):
    def __init__(self, plan_id, api=None):
        Log.DEBUG("Initiating deactivate subscription plan request")
        super().__init__(plan_id, api)
        self._name = "Deactivate Plan Details"
        self._signature = ApiType.DEACTIVATE_PLAN
        self._method = HttpMethod.delete.value
