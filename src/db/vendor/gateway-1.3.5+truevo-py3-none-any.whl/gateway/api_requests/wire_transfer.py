from gateway.request import HttpMethod

from ..api_resources import Currency, BankDetails, AccountHolder
from ..common import Fields, Route, Separator
from ..request import Request
from ..log import Log


class SaveWireTransferBankDetails(Request):

    def __init__(self, currency, bank_details, account_holder,
                 default=False, european=False, description=None, api=None,
                 initial_log=True):
        if initial_log:
            Log.DEBUG("Initiating save wire transfer bank details request")
        super().__init__(api)
        self._name = "Save Wire Transfer Bank Details"
        self._route = Separator.FORWARD_SLASH + self.api.key + \
            Route.WIRE_TRANSFER
        self.__currency = Currency(currency)
        self._bank_details = bank_details if isinstance(
            bank_details, BankDetails) else None
        self._account_holder = account_holder if isinstance(
            account_holder, AccountHolder) else None
        self._default = default
        self._european = european
        self._description = description

    def to_dict(self):
        return {
            Fields.default.value: self._default,
            Fields.european.value: self._european,
            Fields.merchant_id.value: self.api.key,
            Fields.currency_code.value: self.__currency,
            Fields.account_holder.value: self._account_holder,
            Fields.bank.value: self._bank_details,
            Fields.description.value: self._description
        }


class UpdateWireTransferBankDetails(SaveWireTransferBankDetails):
    def __init__(self, registration_id, currency, bank_details,
                 account_holder, default=False, european=False,
                 description=None, api=None):
        Log.DEBUG("Initiating update wire transfer bank details request")
        super().__init__(currency, bank_details, account_holder, default,
                         european, description, api, initial_log=False)
        self._name = "Update Wire Transfer Bank Details"
        self._method = HttpMethod.put.value
        self._route = Separator.FORWARD_SLASH + self.api.key + \
            Route.WIRE_TRANSFER + \
            Separator.FORWARD_SLASH + registration_id


class GetWireTransferBankDetails(Request):
    def __init__(self, registration_id, api=None):
        Log.DEBUG("Initiating get wire transfer bank details request")
        super().__init__(api)
        self._name = "Get Wire Transfer Bank Details"
        self._method = HttpMethod.get.value
        self._route = Separator.FORWARD_SLASH + self.api.key + \
            Route.WIRE_TRANSFER + \
            Separator.FORWARD_SLASH + registration_id


class DeleteWireTransferBankDetails(Request):
    def __init__(self, registration_id, api=None):
        Log.DEBUG("Initiating delete wire transfer bank details request")
        super().__init__(api)
        self._name = "Delete Wire Transfer Bank Details"
        self._method = HttpMethod.delete.value
        self._route = Separator.FORWARD_SLASH + self.api.key + \
            Route.WIRE_TRANSFER + \
            Separator.FORWARD_SLASH + registration_id


class ApproveWireTransferTransaction(Request):
    def __init__(self, txn_reference, api=None):
        Log.DEBUG("Initiating approve wire transfer transaction request")
        super().__init__(api)
        self._name = "Approve Wire Transfer transaction"
        self._method = HttpMethod.post.value
        self._route = Separator.FORWARD_SLASH + self.api.key + \
            Route.WIRE_TRANSFER + "/transaction/" + txn_reference


class DeclineWireTransferTransaction(Request):
    def __init__(self, txn_reference, api=None):
        Log.DEBUG("Initiating decline wire transfer transaction request")
        super().__init__(api)
        self._name = "Decline Wire Transfer transaction"
        self._route = Separator.FORWARD_SLASH + self.api.key + \
            Route.WIRE_TRANSFER + "/transaction/" + txn_reference
        self._method = HttpMethod.delete.value
