from ..api_resources import Events
from ..common import Fields, Route
from ..request import Request
from ..api import Api
from ..log import Log


class _Webhook(Request):

    def __init__(self, webhook_id=None, endpoint=None, events=None, api=None):
        super().__init__(api)
        self._route = Route.PARTNER_API
        self._webhook_id = webhook_id
        self._endpoint = endpoint
        self._events = list(events) if events else None
        self.set_api(api)

    @property
    def events(self):
        return ",".join([x.value for x in self._events])


class CreateWebhook(_Webhook):

    def __init__(self, endpoint, events=None, api=None):
        Log.DEBUG("Initiating create webhook request")
        if events is None:
            events = [Events.all]
        self._name = "Create webhook"
        super().__init__(endpoint=endpoint, events=events, api=api)

    def to_dict(self):
        return {
            Fields.merchant_id.value: self.api.key,
            "webhook": {
                "events": self.events,
                "url": self._endpoint,
            },
        }


class WebhookStatus(_Webhook):

    def __init__(self, webhook_id, api=None):
        Log.DEBUG("Initiating webhook status request")
        self._name = "Webhook details"
        super().__init__(webhook_id=webhook_id, api=api)

    def to_dict(self):
        return {
            Fields.merchant_id.value: self.api.key,
            "webhook": {
                "webhookId": self._webhook_id,
            },
        }


class DeleteWebhook(_Webhook):

    def __init__(self, webhook_id, api=None):
        Log.DEBUG("Initiating delete webhook request")
        self._name = "Delete webhook"
        super().__init__(webhook_id=webhook_id, api=api)

    def to_dict(self):
        return {
            Fields.merchant_id.value: self.api.key,
            "webhook": {
                "webhookId": self._webhook_id,
                "status": "inactive",
            },
        }


class UpdateWebhook(_Webhook):

    def __init__(self, webhook_id, endpoint, events, api=None):
        Log.DEBUG("Initiating update webhook request")
        self._name = "Create webhook"
        super().__init__(webhook_id, endpoint, events, api)

    def to_dict(self):
        return {
            Fields.merchant_id.value: self.api.key,
            "webhook": {
                "webhookId": self._webhook_id,
                "url": self._endpoint,
                "events": self.events,
            },
        }


def decrypt_webhook_data(data):
    """Decrypt data and convert to python representation"""
    return Api.get().decrypt_and_convert(data)
