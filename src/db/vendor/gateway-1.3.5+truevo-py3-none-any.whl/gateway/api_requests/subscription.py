from gateway import CustomerID, Txn
from gateway.common import Fields, Route, ApiType, Separator
from gateway.request import AuthTokenRequest, HttpMethod
from gateway.utils import merge_dicts
from gateway.log import Log


class _Subscription(AuthTokenRequest):
    def __init__(self, api=None, subscription_id=None):
        super().__init__(api)
        self._route = Separator.FORWARD_SLASH + self.api.key + \
            Route.SUBSCRIPTIONS
        if subscription_id:
            self._route = self._route + \
                Separator.FORWARD_SLASH + subscription_id


class CreateSubscription(_Subscription):
    def __init__(self, customer_id, plan_id, txn,
                 start_date, quantity,
                 subscription_id=None, opts=None,
                 **kwargs):
        if "initial_log" not in kwargs.keys():
            Log.DEBUG("Initiating create subscription request")
        super().__init__(subscription_id=subscription_id)
        self._name = "Create Subscription"
        self._signature = ApiType.CREATE_SUBSCRIPTION
        self._plan_id = plan_id
        self._start_date = start_date
        self._txn_id = txn if isinstance(txn, Txn) else Txn(None)
        self._quantity = quantity
        config = merge_dicts(opts or {}, kwargs)
        self.__customer_id = customer_id if isinstance(
            customer_id, CustomerID) else CustomerID(customer_id)
        self.set_api(config.get("api"))
        self._allow3d = config.get("allow3d")
        self.__url = config.get("url")
        self.__automatic_debit = config.get("automaticDebit")
        self.__dynamic_descriptor = config.get("dynamic_descriptor")
        self._description = config.get("description")
        self._total_cycles = config.get("total_cycles")
        self._expire_in = config.get("expire_in")
        self._external = config.get("external", False)
        self._customer = config.get("customer")
        self._custom_data = config.get("custom_data")

    @property
    def url(self):
        return self.__url

    def sync(self):
        self.assync = True
        return self

    def allow3d(self):
        self._allow3d = True
        return self

    def to_dict(self):
        data = {
            "lang": self.lang,
            Fields.merchant.value: {
                Fields.merchant_id.value: self.api.key,
                Fields.customer_id.value: self.__customer_id,
            },
            "external": self._external,
            Fields.plan_id.value: self._plan_id,
            Fields.start_date.value: self._start_date,
            Fields.quantity.value: self._quantity,
            Fields.transaction.value: {
                Fields.txn_ref.value: self.txn_id,
            },
        }
        if self.url:
            data["url"] = self.__url
        if self.__dynamic_descriptor:
            data['dynamicDescriptor'] = self.__dynamic_descriptor
        if self._allow3d is not None:
            data[Fields.transaction.value][
                Fields.allow3d.value] = self._allow3d
        if self.__automatic_debit is not None:
            data[Fields.transaction.value][
                Fields.automatic_debit.value] = self.__automatic_debit
        data.update(merge_dicts(
            {},
            {Fields.description.value: self._description},
            {Fields.total_cycles.value: self._total_cycles},
            {Fields.expire_in.value: self._expire_in},
            allow_empty=False
        ))
        if self._customer:
            data[Fields.customer.value] = self._customer
        if self._custom_data:
            data[Fields.CUSTOM_DATA.value] = self._custom_data
        return data


class UpdateSubscription(CreateSubscription):
    def __init__(self, customer_id, subscription_id, txn,
                 start_date, quantity, opts=None, **kwargs):
        Log.DEBUG("Initiating update subscription request")
        kwargs['initial_log'] = None
        super().__init__(customer_id=customer_id, plan_id=None, txn=txn,
                         start_date=start_date, quantity=quantity,
                         subscription_id=subscription_id, opts=opts,
                         **kwargs)
        self._name = "Update Subscription"
        self._signature = ApiType.UPDATE_SUBSCRIPTION
        self._method = HttpMethod.put.value
        self._txn_id = subscription_id


class DeactivateSubscription(_Subscription):
    def __init__(self, subscription_id, api=None):
        Log.DEBUG("Initiating deactivate subscription request")
        super().__init__(api=api, subscription_id=subscription_id)
        self._name = "Deactivate Subscription"
        self._signature = ApiType.DEACTIVATE_SUBSCRIPTION
        self._method = HttpMethod.delete.value
        self._txn_id = subscription_id


class GetSubscriptionDetails(_Subscription):
    def __init__(self, subscription_id, api=None):
        Log.DEBUG("Initiating get subscription details request")
        super().__init__(api=api, subscription_id=subscription_id)
        self._name = "Get Subscription Details"
        self._signature = ApiType.GET_SUBSCRIPTION_DETAILS
        self._method = HttpMethod.get.value
        self._txn_id = subscription_id


class ScheduleUpdateSubscription(_Subscription):
    def __init__(self, subscription_id, plan_id, start_date, apply_date,
                 quantity, api=None, opts=None, **kwargs):
        Log.DEBUG("Initiating schedule update subscription request")
        super().__init__(api=api, subscription_id=subscription_id)
        self._name = "Schedule Update Subscription"
        self._signature = ApiType.SCHEDULE_UPDATE_SUBSCRIPTION
        self._method = HttpMethod.put.value
        self._txn_id = subscription_id
        self.plan_id = plan_id
        self.start_date = start_date
        self.apply_date = apply_date
        self.quantity = quantity
        config = merge_dicts(opts or {}, kwargs)
        self._automatic_debit = config.get("automatic_debit")
        self._total_cycle = config.get("total_cycle")
        self._description = config.get("description")
        self._expire_in = config.get("expire_in")

    def to_dict(self):
        data = {
            "lang": self.lang,
            "planId": self.plan_id,
            "quantity": self.quantity,
            "applyDate": self.apply_date,
            "start_date": self.start_date,
        }
        data = merge_dicts(
            data,
            {Fields.description.value: self._description},
            {Fields.total_cycles.value: self._total_cycle},
            {Fields.expire_in.value: self._expire_in},
            {Fields.automatic_debit.value: self._automatic_debit},
            allow_empty=False
        )
        return data
