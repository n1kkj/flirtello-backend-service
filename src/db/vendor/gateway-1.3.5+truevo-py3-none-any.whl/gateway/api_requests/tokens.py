from ..api_resources import Token, CardTypes, Modes, Address
from ..common import Fields, Route
from ..request import Request
from ..log import Log


class _TokenRequest(Request):

    def __init__(self, customer_id, token, api=None):
        super().__init__(api)
        self._route = Route.PARTNER_API
        self.customer_id = customer_id
        self.token = Token(token)
        self.set_api(api)


class GetAcquirerTokens(_TokenRequest):

    def __init__(
            self,
            customer_id,
            api=None):
        Log.DEBUG("Initiating get acquirer token request")
        self._name = "Get acquirer tokens"
        super().__init__(customer_id, None, api)

    def to_dict(self):
        return {
            Fields.merchant_id.value: self.api.key,
            Fields.customer_id.value: self.customer_id,
            Fields.all_cards.value: False,
        }


class GetSavedCards(_TokenRequest):

    def __init__(
            self,
            customer_id,
            card_type=None,
            payment_mode=None,
            api=None):
        Log.DEBUG("Initiating get saved cards request")
        self._name = "Get saved card tokens"
        self.__card_type = card_type
        self.__payment_mode = payment_mode
        super().__init__(customer_id, None, api)

    def to_dict(self):
        data = {
            Fields.merchant_id.value: self.api.key,
            Fields.customer_id.value: self.customer_id,
            Fields.all_cards.value: True,
        }
        if isinstance(self.__card_type, CardTypes):
            data[Fields.card_type.value] = self.__card_type
        if isinstance(self.__payment_mode, Modes):
            data[Fields.card_type.value] = self.__payment_mode
        return data


class DeleteToken(_TokenRequest):
    def __init__(self, customer_id, token, api=None):
        Log.DEBUG("Initiating delete token request")
        self._name = "Delete Token"
        super().__init__(customer_id, token, api)

    def to_dict(self):
        return {
            Fields.merchant_id.value: self.api.key,
            Fields.customer_id.value: self.customer_id,
            Fields.token_id.value: self.token,
        }


class SaveCard(_TokenRequest):

    def __init__(
            self,
            customer_id,
            card_detail,
            address=None,
            api=None):
        Log.DEBUG("Initiating save card request")
        self._name = "Save card"
        self.__card_detail = card_detail
        self.__address = address
        super().__init__(customer_id, None, api)

    def to_dict(self):
        data = {
            Fields.merchant_id.value: self.api.key,
            Fields.customer_id.value: self.customer_id,
            Fields.card.value: self.__card_detail,
        }
        if isinstance(self.__address, Address):
            data[Fields.customer.value] = self.__address
        return data


class SaveAcquirerTokens(_TokenRequest):

    def __init__(
            self,
            customer_id,
            token,
            acquirer,
            expiry_month,
            expiry_year,
            name,
            bank_info_number,
            last4,
            api=None):
        Log.DEBUG("Initiating save acquirer tokens request")
        super().__init__(customer_id, token, api)
        self._name = "Save acquirer tokens"
        self.__acquirer = acquirer
        self.__expiry_month = expiry_month
        self.__expiry_year = expiry_year
        self.__name = name
        self.__bank_info_number = bank_info_number
        self.__last4 = last4

    def to_dict(self):
        return {
            Fields.merchant_id.value: self.api.key,
            Fields.customer_id.value: self.customer_id,
            Fields.token.value: {
                Fields.acquirer_token.value: self.token,
                Fields.acquirer.value: self.__acquirer,
                Fields.card_month.value: self.__expiry_month,
                Fields.card_year.value: self.__expiry_year,
                Fields.card_name.value: self.__name,
                Fields.card_bin.value: self.__bank_info_number,
                Fields.card_last4.value: self.__last4,
            }
        }


class VerifyToken(Request):

    def __init__(self, token, api=None):
        Log.DEBUG("Initiating verify token request")
        super().__init__(api)
        self._name = "Verify tokens"
        self._route = Route.PARTNER_API
        self.token = Token(token)
        self.set_api(api)

    def to_dict(self):
        return {
            Fields.merchant_id.value: self.api.key,
            Fields.token_id.value: self.token,
        }


class VerifyCard(Request):

    def __init__(self, token, api=None):
        super().__init__(api)
        self._name = "Verify card"
        self._route = Route.PARTNER_API
        self.token = Token(token)
        self.set_api(api)

    def to_dict(self):
        return {
            Fields.merchant_id.value: self.api.key,
            Fields.token_id.value: self.token,
            Fields.all_cards.value: True,
        }
