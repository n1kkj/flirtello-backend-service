from base64 import b16encode, b16decode
from os import urandom

from cryptography import x509
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.hashes import SHA1
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from json import JSONDecoder as _Decoder, JSONDecodeError

from .exceptions import ConfigurationError

from .log import Log


class Crypt:
    """AES-256-CBC crypto class"""

    IV_LENGTH = 16

    def __init__(self, conf_token, conf_cert):

        def get_repr_fp(cert):
            fingerprint = x509.load_pem_x509_certificate(
                    cert, default_backend()).fingerprint(SHA1())
            fingerprint = b16encode(fingerprint).decode()
            return ":".join(str(fingerprint[i:i+2]).upper() for i in range(
                0, len(fingerprint), 2))

        def gen_key(fp):
            token = conf_token
            return ("".join(
                    chr(ord(x) | ord(y))
                    for x, y in zip(fp, token))[:len(token)]).encode()

        try:
            with open(conf_cert, 'rb') as f:
                pub = f.read()
                f.close()
            fingerprint = get_repr_fp(pub)
            encryptkey = gen_key(fingerprint)
        except TypeError as e:
            raise ConfigurationError(e)

        aes = algorithms.AES(encryptkey)
        self.BLOCK_SIZE = aes.block_size
        self.KEY_LENGTH = int(aes.key_size / 8)

        self.__decryptkey = fingerprint[:self.KEY_LENGTH].encode()
        self.__encryptkey = encryptkey

    def __cipher(self, key, iv):
        aes = algorithms.AES(key)
        return Cipher(aes, modes.CBC(iv), backend=default_backend())

    def encryptor(self, iv):
        """Get encryptor context"""
        return self.__cipher(self.__encryptkey, iv).encryptor()

    def decryptor(self, iv):
        return self.__cipher(self.__decryptkey, iv).decryptor()

    def __pad_data(self, data):
        """Add null padding to data"""
        block_bytes = int(self.BLOCK_SIZE / 8)
        data = data + bytes((block_bytes - len(data) % block_bytes))
        return data

    def __unpad_data(self, data):
        """Remove padding from data"""
        return data.decode().strip()

    def __unpad_data_and_convert(self, data):
        """Remove padding from data and convert to python representation"""
        try:
            return _Decoder().decode(data.decode().strip())
        except (UnicodeDecodeError, JSONDecodeError) as e:
            Log.DEBUG("Error decoding with UTF-8 or " +
                      "converting to python representation: %s", str(e))
            return _Decoder().decode(data.decode("utf-16be").strip())

    def encrypt(self, data):
        """Encrypt content"""
        Log.DEBUG("Data before encryption: %s", data)
        iv = urandom(self.IV_LENGTH)
        encryptor = self.encryptor(iv)
        return b16encode(iv + (encryptor.update(self.__pad_data(
            data)) + encryptor.finalize()))

    def decrypt(self, data):
        """Decrypt content"""
        data = b16decode(data.upper())
        decryptor = self.decryptor(data[:self.IV_LENGTH])
        decrypted_data = self.__unpad_data(
            decryptor.update(data[self.IV_LENGTH:]) + decryptor.finalize())
        Log.DEBUG("Data after decryption: %s", decrypted_data)
        return decrypted_data

    def decrypt_and_convert(self, data):
        """Decrypt content and convert to python representation"""
        data = b16decode(data.upper())
        decryptor = self.decryptor(data[:self.IV_LENGTH])
        decrypted_data = self.__unpad_data_and_convert(
            decryptor.update(data[self.IV_LENGTH:]) + decryptor.finalize())
        Log.DEBUG("Data after decryption and " +
                  "conversion to python representation: %s", decrypted_data)
        return decrypted_data
